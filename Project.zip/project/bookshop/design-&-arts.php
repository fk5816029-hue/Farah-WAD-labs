<?php
include "connect.php";

$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}
$category_id = isset($_GET['id']) ? intval($_GET['id']) : 5;

$subQuery = "SELECT * FROM subcategories WHERE category_id = $category_id ORDER BY id ASC";

$subQuery = "SELECT * FROM subcategories WHERE category_id = $category_id ORDER BY id ASC";
$subResult = mysqli_query($conn, $subQuery);


// Get subcategory if selected
$subcategory_id = isset($_GET['sub']) ? intval($_GET['sub']) : 0;

// Build SQL
$query = "
    SELECT books.*, subcategories.name AS genre
    FROM books
    LEFT JOIN subcategories
    ON books.subcategory_id = subcategories.id
    WHERE books.category_id = $category_id
";

if ($subcategory_id > 0) {
    $query .= " AND books.subcategory_id = $subcategory_id";
}

$result = mysqli_query($conn, $query);

$books = [];
while ($book = mysqli_fetch_assoc($result)) {
    $books[] = $book;
}


// FETCH DATA AS ARRAY

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Design Books - Online Book Store</title>
 <style>
  /* Base styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
 .star {
        width: 15px;
        height: 15px;
        margin-bottom: 5px;
        display: inline-block;
        background: url('data:image/svg+xml;utf8,<svg fill="none" stroke="%23f1c40f" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><polygon points="12,2 15,9 22,9 17,14 19,21 12,17 5,21 7,14 2,9 9,9"/></svg>') no-repeat center;
        background-size: contain;
        margin-right: 3px;
    }

    .star.filled {
      width: 18px;
        height: 18px;
        background: url('data:image/svg+xml;utf8,<svg fill="%23f1c40f" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><polygon points="12,2 15,9 22,9 17,14 19,21 12,17 5,21 7,14 2,9 9,9"/></svg>') no-repeat center;
        background-size: contain;
    }
body {
  display: flex;
  background-color: #f5f7fa;
  color: #333;
  transition: background-color 0.3s, color 0.3s;
}

/* Sidebar styles */
.sidebar {
  width: 250px;
  height: 100vh;
  background: linear-gradient(180deg, #2c3e50, #1a2530);
  color: white;
  padding: 20px;
  position: fixed;
  overflow-y: auto;
}

.logo {
  display: flex;
  align-items: center;
  margin-bottom: 30px;
}

.logo img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
}

.logo h2 {
  font-size: 1.2rem;
  font-weight: 600;
}

.nav-links {
  display: flex;
  flex-direction: column;
}

.nav-links a {
  color: #ecf0f1;
  text-decoration: none;
  padding: 12px 15px;
  margin: 5px 0;
  border-radius: 5px;
  transition: all 0.3s;
}

.nav-links a:hover, .nav-links a.active {
  background-color: #3498db;
  color: white;
}

.dropdown {
  position: relative;
    margin: 5px 0;
      padding:12px 0px;
}

.dropdown-content {
  display: none;
  position: absolute;
  left: 0%;
  top: 120%;
  background-color: #34495e;
  min-width: 200px;
  border-radius: 5px;
  box-shadow: 0 8px 16px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown-content a {
  display: block;
  padding: 10px 15px;
}

/* Main content styles */
.main-content {
  flex: 1;
  margin-left: 250px;
  padding: 20px;
}

.topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding: 15px 20px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

.search-container {
  display: flex;
  gap: 10px;
}

.search-container input {
  padding: 10px 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
  width: 300px;
}

.search-container button, #theme-toggle {
  padding: 10px 20px;
  background-color: #3498db;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.search-container button:hover, #theme-toggle:hover {
  background-color: #2980b9;
}
  .book-genre {
      display: inline-block;
      background-color: #e8f4fc;
      color: #3498db;
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.8rem;
      margin-bottom: 10px;
    }
/* Hero section */
.hero {
  background: linear-gradient(135deg, #3498db, #8e44ad);
  color: white;
  padding: 40px;
  border-radius: 10px;
  margin-bottom: 30px;
  text-align: center;
}

.hero h1 {
  font-size: 2.5rem;
  margin-bottom: 15px;
}

.hero p {
  font-size: 1.2rem;
  max-width: 700px;
  margin: 0 auto;
}

/* Books Grid */
.books-section {
  margin-bottom: 40px;
}

.books-section h2 {
  margin-bottom: 20px;
  font-size: 1.8rem;
  color: #2c3e50;
}

.books-content {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 25px;
}

.book-item {
  background-color: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
}

.book-item:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}

.book-item h4 {
  padding: 15px 20px;
  background-color: #f8f9fa;
  border-bottom: 1px solid #eee;
  color: #2c3e50;
}

.book-cover {
  width: 100%;
  height: 200px;
  overflow: hidden;
  position: relative;
}

.book-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.book-item:hover .book-cover img {
  transform: scale(1.05);
}

.book-details {
  padding: 15px 20px;
}

.book-author {
  color: #7f8c8d;
  font-style: italic;
  margin-bottom: 10px;
}

.book-price {
  font-size: 1.2rem;
  font-weight: bold;
  color: #27ae60;
  margin-bottom: 15px;
}

.book-actions {
  display: flex;
  gap: 10px;
}

.btn {
  padding: 8px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
  flex: 1;
  text-align: center;
  text-decoration: none;
  font-size: 0.9rem;
}

.btn-primary {
  background-color: #3498db;
  color: white;
}

.btn-primary:hover {
  background-color: #2980b9;
}

.btn-secondary {
  background-color: #e74c3c;
  color: white;
}

.btn-secondary:hover {
  background-color: #c0392b;
}

/* Footer */
.footer {
  background-color: #2c3e50;
  color: white;
  padding: 30px;
  border-radius: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.social-icons {
  display: flex;
  gap: 15px;
}

.social-icons img {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  transition: transform 0.3s;
}

.social-icons img:hover {
  transform: scale(1.1);
}

/* Dark mode styles */
body.dark-mode .book-genre {
  background-color: #1a1a2e;
  color: #e6e6e6;
}

body.dark-mode .topbar,
body.dark-mode .book-item {
  background-color: #16213e;
  color: #e6e6e6;
}

body.dark-mode .book-item h4 {
  background-color: #0f3460;
  color: #e6e6e6;
}

body.dark-mode .book-details {
  color: #b8b8b8;
}

body.dark-mode .search-container input {
  background-color: #16213e;
  border-color: #0f3460;
  color: #e6e6e6;
}

/* Subcategories Section */
.subcategories-section {
  margin: 40px 0;
  padding: 30px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 15px;
  color: white;
}

.subcategories-section h2 {
  text-align: center;
  margin-bottom: 30px;
  font-size: 2rem;
  color: white;
}

.subcategories-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
}

.subcategory-card {
  background: rgba(255, 255, 255, 0.1);
  padding: 25px;
  border-radius: 10px;
  text-align: center;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  transition: transform 0.3s, background 0.3s;
}

.subcategory-card:hover {
  transform: translateY(-5px);
  background: rgba(255, 255, 255, 0.2);
}

.subcategory-icon {
  font-size: 3rem;
  margin-bottom: 15px;
}

.subcategory-card h3 {
  margin-bottom: 10px;
  font-size: 1.3rem;
  color: white;
}

.subcategory-card p {
  margin-bottom: 10px;
  opacity: 0.9;
  font-size: 0.9rem;
}

.subcategory-card .book-count {
  background: rgba(255, 255, 255, 0.2);
  padding: 5px 12px;
  border-radius: 15px;
  font-size: 0.8rem;
  font-weight: 500;
}

/* Design-specific book styles */
.book-item .book-cover::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0));
  z-index: 1;
}

.book-item:hover .book-cover::before {
  background: linear-gradient(45deg, rgba(255,255,255,0.2), rgba(255,255,255,0.1));
}

/* Design category filters */
.design-filters {
  background: white;
  padding: 20px;
  border-radius: 10px;
  margin-bottom: 30px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

.design-filters h3 {
  margin-bottom: 15px;
  color: #2c3e50;
  font-size: 1.2rem;
}

.filter-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 15px;
}

.filter-tag {
  background: #e8f4fc;
  color: #3498db;
  padding: 8px 15px;
  border-radius: 20px;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.3s;
  border: 2px solid transparent;
}

.filter-tag:hover, .filter-tag.active {
  background: #3498db;
  color: white;
  border-color: #2980b9;
}

/* Dark mode adjustments for design section */
body.dark-mode .subcategories-section {
  background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
}

body.dark-mode .subcategory-card {
  background: rgba(255, 255, 255, 0.05);
  border-color: rgba(255, 255, 255, 0.1);
}

body.dark-mode .design-filters {
  background-color: #16213e;
}

body.dark-mode .design-filters h3 {
  color: #e6e6e6;
}

body.dark-mode .filter-tag {
  background: #2c3e50;
  color: #bdc3c7;
  border-color: #34495e;
}

body.dark-mode .filter-tag:hover, 
body.dark-mode .filter-tag.active {
  background: #3498db;
  color: white;
  border-color: #2980b9;
}

/* Popup styles */
.custom-popup {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0,0,0,0.9);
  color: white;
  padding: 20px 30px;
  border-radius: 10px;
  z-index: 10000;
  font-size: 16px;
  text-align: center;
  box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  min-width: 250px;
}

/* Wishlist button active state */
.wishlist-btn.active {
  background-color: #e74c3c !important;
}

.wishlist-btn.active:hover {
  background-color: #c0392b !important;
}

/* Cart and Wishlist counters */
.cart-counter, .wishlist-counter {
  position: relative;
  display: inline-block;
}

.cart-badge, .wishlist-badge {
  position: absolute;
  top: -8px;
  right: -8px;
  background-color: #e74c3c;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  font-size: 0.7rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
}

/* Loading animation */
.loading {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #3498db;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Success/Error messages */
.message {
  padding: 10px 15px;
  border-radius: 5px;
  margin: 10px 0;
  font-weight: 500;
}

.message.success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.message.error {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

/* Price range slider */
.price-range {
  width: 100%;
  margin: 10px 0;
}

.price-labels {
  display: flex;
  justify-content: space-between;
  font-size: 0.8rem;
  color: #7f8c8d;
}

/* Book hover effects */
.book-item {
  position: relative;
  overflow: hidden;
}

.book-item::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
  transition: left 0.5s;
}

.book-item:hover::before {
  left: 100%;
}

/* Quick view modal */
.quick-view-modal {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.8);
  z-index: 1000;
  align-items: center;
  justify-content: center;
}

.quick-view-content {
  background-color: white;
  padding: 30px;
  border-radius: 10px;
  max-width: 600px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

/* Scrollbar styling */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}
 .design-subcategories {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 30px;
      border-radius: 15px;
      margin-bottom: 30px;
      color: white;
    }

    .design-subcategories h2 {
      text-align: center;
      margin-bottom: 25px;
      font-size: 1.8rem;
      color: white;
    }

    .design-subcategories-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
    }

    .design-subcategory-tag {
      background: rgba(255, 255, 255, 0.1);
      padding: 15px;
      border-radius: 10px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .design-subcategory-tag:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-3px);
    }

    .design-subcategory-tag.active {
      background: rgba(255, 255, 255, 0.3);
      border-color: rgba(255, 255, 255, 0.4);
    }

/* Responsive design */
@media (max-width: 1024px) {
  .books-content {
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  }
  
  .subcategories-grid {
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  }
}

@media (max-width: 768px) {
  .sidebar {
    width: 70px;
    padding: 15px 10px;
  }
    .design-subcategories-grid {
        grid-template-columns: repeat(2, 1fr);
      }
  .logo h2, .nav-links a span {
    display: none;
  }
  
  .main-content {
    margin-left: 70px;
  }
  
  .topbar {
    flex-direction: column;
    gap: 15px;
  }
  
  .search-container {
    width: 100%;
  }
  
  .search-container input {
    width: 100%;
  }
  
  .books-content {
    grid-template-columns: 1fr;
  }
  
  .subcategories-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .subcategories-section {
    padding: 20px;
  }
  
  .footer {
    flex-direction: column;
    gap: 20px;
    text-align: center;
  }
  
  .filter-tags {
    justify-content: center;
  }
}

@media (max-width: 480px) {
  .sidebar {
    display: none;
  }
  
  .main-content {
    margin-left: 0;
  }
  
  .hero {
    padding: 20px;
  }
  
  .hero h1 {
    font-size: 2rem;
  }
  
  .book-actions {
    flex-direction: column;
  }
  .design-subcategories-grid {
        grid-template-columns: 1fr;
      }
      
      .design-subcategories {
        padding: 20px;
      }
  .subcategories-grid {
    grid-template-columns: 1fr;
  }
  
  .subcategory-card {
    padding: 20px;
  }
  
  .category-stats {
    flex-direction: column;
    gap: 5px;
  }
}

/* Print styles */
@media print {
  .sidebar, .topbar, .footer, .book-actions {
    display: none;
  }
  
  .main-content {
    margin-left: 0;
  }
  
  .book-item {
    break-inside: avoid;
    box-shadow: none;
    border: 1px solid #ddd;
  }
}
 </style>
</head>
<body>
  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Online Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.html">Home</a>
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
           <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
      <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="main-content">
    <header class="topbar">
      <div class="search-container">
        <input id="search-input" type="text" placeholder="Search design books..." />
        <button onclick="searchSite()">Search</button>
      </div>
      <button id="theme-toggle">Dark Mode</button>
    </header>

    <!-- Hero Section -->
    <section class="hero">
      <h1>Design & Arts Books</h1>
      <p>Explore graphic design, UI/UX, architecture, photography, and creative arts with our curated collection of design books.</p>
    </section>
 <section class="design-subcategories">
    <h2>Explore Design & Arts Categories</h2>

    <div class="design-subcategories-grid">

        <!-- Always show ALL category -->
        <div class="design-subcategory-tag active" onclick="filterBooks('all')">
           All Design & Arts
        </div>

        <!-- Load Dynamic Subcategories -->
        <?php
        if (mysqli_num_rows($subResult) > 0) {
            while ($sub = mysqli_fetch_assoc($subResult)) { 
                $subName = $sub['name'];
                $subSlug = strtolower(str_replace(' ', '-', $subName));
        ?>
                <div class="design-subcategory-tag" onclick="filterBooks('<?php echo $subSlug; ?>')">
                    <?php echo $subName; ?>
                </div>
        <?php
            }
        } else {
            echo "<p>No subcategories found.</p>";
        }
        ?>

    </div>
</section>
    <!-- Design Books Content -->
    <section class="books-section">
      <h2>Design & Creative Arts Collection</h2>
         <div class="books-content">

        <?php if (count($books) > 0): ?>
            <?php foreach ($books as $book): ?>

                <div class="book-item" data-genre="<?php echo strtolower($book['genre']); ?>">

                    <h4><?php echo $book['title']; ?></h4>

                    <div class="book-cover">
                    <img src="<?php echo $book['cover_image']; ?>" alt="<?php echo $book['title']; ?> Book Cover">
   
                    <!-- <img src="uploads/<?php echo $book['image']; ?>" alt="<?php echo $book['title']; ?> Book Cover"> -->
                    </div>

                    <div class="book-details">
                        <p class="book-author">by <?php echo $book['publisher']; ?></p>

                        <!-- <div class="book-rating">
                            ⭐⭐⭐⭐⭐ <?php echo $book['rating']; ?>/5
                        </div> -->
<div class="star-rating">
    <?php 
        $rating = intval($book['rating']); // 0–5

        for ($i = 1; $i <= 5; $i++) {
            if ($i <= $rating) {
                echo '<span class="star filled"></span>';
            } else {
                echo '<span class="star"></span>';
            }
        }
    ?>
</div>

                                   
                        <span class="book-genre"><?php echo $book['genre']; ?></span>

                        <p class="book-description"><?php echo $book['description']; ?></p>

                        <p class="book-price">$<?php echo $book['price']; ?></p>

                        <div class="book-actions">
                            <button class="btn btn-primary" 
                                onclick="addToCart('<?php echo $book['id']; ?>', '<?php echo $book['title']; ?>', <?php echo $book['price']; ?>)">
                                Add to Cart
                            </button>

                            <button class="btn btn-secondary" 
                                onclick="orderNow('<?php echo $book['id']; ?>', '<?php echo $book['title']; ?>')">
                                Order Now
                            </button>
                        </div>
                    </div>
                </div>

            <?php endforeach; ?>

        <?php else: ?>
            <p>No books found in this category.</p>
        <?php endif; ?>

    </div>
      
    </section>

    <!-- Design Subcategories -->
    <section class="subcategories-section">
      <h2>Design Specializations</h2>
      <div class="subcategories-grid">
        <div class="subcategory-card">
          <div class="subcategory-icon">🎨</div>
          <h3>Graphic Design</h3>
          <p>Typography, layout, branding</p>
          <span class="book-count">180+ Books</span>
        </div>
        <div class="subcategory-card">
          <div class="subcategory-icon">📱</div>
          <h3>UI/UX Design</h3>
          <p>User experience, interfaces</p>
          <span class="book-count">120+ Books</span>
        </div>
        <div class="subcategory-card">
          <div class="subcategory-icon">🏛️</div>
          <h3>Architecture</h3>
          <p>Building design, structures</p>
          <span class="book-count">95+ Books</span>
        </div>
        <div class="subcategory-card">
          <div class="subcategory-icon">📸</div>
          <h3>Photography</h3>
          <p>Composition, techniques</p>
          <span class="book-count">150+ Books</span>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><img src="images/Facebook.jpg" alt="Facebook"></a>
        <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.jpg" alt="Instagram"></a>
        <a href="https://www.youtube.com" target="_blank"><img src="images/youtube.png" alt="YouTube"></a>
      </div>
    </footer>
  </main> 

  <script>
      const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
    // Design-specific JavaScript functions
    function searchDesignBooks() {
      const searchInput = document.getElementById('search-input');
      if (!searchInput || !searchInput.value.trim()) {
        showPopup("Please type something to search!");
        return;
      }
      
      const query = searchInput.value.toLowerCase().trim();
      const bookItems = document.querySelectorAll('.book-item');
      const subcategoryCards = document.querySelectorAll('.subcategory-card');
      
      let foundBooks = false;
      let foundCategories = false;
      
      // Search in books
      bookItems.forEach(function(book) {
        const title = book.querySelector('h4').textContent.toLowerCase();
        const author = book.querySelector('.book-author').textContent.toLowerCase();
        const description = book.querySelector('.book-details p:not(.book-price)').textContent.toLowerCase();
        
        if (title.includes(query) || author.includes(query) || description.includes(query)) {
          book.style.display = 'block';
          foundBooks = true;
        } else {
          book.style.display = 'none';
        }
      });
      
      // Search in subcategories
      subcategoryCards.forEach(function(card) {
        const title = card.querySelector('h3').textContent.toLowerCase();
        const description = card.querySelector('p').textContent.toLowerCase();
        
        if (title.includes(query) || description.includes(query)) {
          card.style.display = 'block';
          foundCategories = true;
        } else {
          card.style.display = 'none';
        }
      });
      
      if (!foundBooks && !foundCategories) {
        showPopup("No design books or categories found for: " + query);
      }
    }

    function filterDesignBooks(category) {
      const bookItems = document.querySelectorAll('.book-item');
      const filterTags = document.querySelectorAll('.filter-tag');
      
      // Update active filter tag
      filterTags.forEach(function(tag) {
        tag.classList.remove('active');
        if (tag.textContent.toLowerCase().includes(category) || (category === 'all' && tag.textContent.includes('All Design'))) {
          tag.classList.add('active');
        }
      });
      
      if (category === 'all') {
        bookItems.forEach(function(book) {
          book.style.display = 'block';
        });
        return;
      }
      
      bookItems.forEach(function(book) {
        const title = book.querySelector('h4').textContent.toLowerCase();
        const description = book.querySelector('.book-details p:not(.book-price)').textContent.toLowerCase();
        
        // Simple keyword matching for categories
        const isGraphicDesign = category === 'graphic' && 
          (title.includes('design') || description.includes('graphic') || 
           description.includes('typography') || description.includes('brand') ||
           description.includes('logo') || description.includes('color'));
        
        const isUIUX = category === 'uiux' && 
          (title.includes('ui') || title.includes('ux') || 
           description.includes('user') || description.includes('interface') ||
           description.includes('usability'));
        
        const isWebDesign = category === 'web' && 
          (title.includes('web') || description.includes('html') || 
           description.includes('css') || description.includes('website'));
        
        const isLogoDesign = category === 'logo' && 
          (title.includes('logo') || description.includes('brand') ||
           description.includes('identity'));
        
        const isColorTheory = category === 'color' && 
          (title.includes('color') || description.includes('color'));
        
        if (isGraphicDesign || isUIUX || isWebDesign || isLogoDesign || isColorTheory) {
          book.style.display = 'block';
        } else {
          book.style.display = 'none';
        }
      });
    }

    function initializeDesignPage() {
      // Add filter tags if they don't exist
      if (!document.querySelector('.design-filters')) {
        const booksSection = document.querySelector('.books-section');
        if (booksSection) {
          const filtersHTML = '<div class="design-filters"><h3>Filter by Specialty</h3><div class="filter-tags"><span class="filter-tag active" onclick="filterDesignBooks(\'all\')">All Design</span><span class="filter-tag" onclick="filterDesignBooks(\'graphic\')">Graphic Design</span><span class="filter-tag" onclick="filterDesignBooks(\'uiux\')">UI/UX Design</span><span class="filter-tag" onclick="filterDesignBooks(\'web\')">Web Design</span><span class="filter-tag" onclick="filterDesignBooks(\'logo\')">Logo Design</span><span class="filter-tag" onclick="filterDesignBooks(\'color\')">Color Theory</span></div></div>';
          booksSection.insertAdjacentHTML('afterbegin', filtersHTML);
        }
      }
      
      // Track design category view
      if (typeof trackCategoryView === 'function') {
        trackCategoryView('design');
      }
    }

    // Override search function for design page
    function searchSite() {
      if (window.location.pathname.includes('design.html')) {
        searchDesignBooks();
      } else {
        // Use default search for other pages
        const input = document.getElementById("search-input");
        if (!input || !input.value.trim()) {
          showPopup("Please type something to search!");
          return;
        }
        // Default search logic would go here
      }
    }

    // Utility functions
    function showPopup(message) {
      const existingPopup = document.querySelector('.custom-popup');
      if (existingPopup) {
        existingPopup.remove();
      }
      
      const popup = document.createElement("div");
      popup.className = 'custom-popup';
      popup.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,0.9); color: white; padding: 20px 30px; border-radius: 10px; z-index: 10000; font-size: 16px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.3); min-width: 250px;';
      popup.textContent = message;
      
      document.body.appendChild(popup);
      
      setTimeout(function() {
        if (document.body.contains(popup)) {
          document.body.removeChild(popup);
        }
      }, 2000);
    }

    function addToCart(bookId, bookTitle, bookPrice) {
      let cart = JSON.parse(localStorage.getItem('bookCart')) || [];
      const existingItem = cart.find(function(item) {
        return item.id === bookId;
      });
      
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push({
          id: bookId,
          title: bookTitle,
          price: bookPrice,
          quantity: 1,
          dateAdded: new Date().toISOString()
        });
      }
      
      localStorage.setItem('bookCart', JSON.stringify(cart));
       let user = localStorage.getItem('user');
let userId = 1; // default if not logged in

if (user) {
    try {
        let userObj = JSON.parse(user);
        if (userObj.id) {
            userId = userObj.id;
        }
    } catch (e) {
        console.error("Error parsing user from localStorage:", e);
    }
}
      let formData = new FormData();
    formData.append('bookId', bookId);
    formData.append('quantity', 1);
    formData.append('userId', userId);

    fetch('add-to-cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        showPopup(`${bookTitle} added to cart!`);
        console.log(data);
    })
    .catch(err => {
        console.error(err);
        showPopup(`Error adding ${bookTitle} to cart.`);
    });
    }
    function removeSlug(genre) {
  return genre.replace(/-/g, ' ');
}
    function filterBooks(genre) {
      genre= removeSlug(genre);
      console.log('genre: ', genre);
      const bookItems = document.querySelectorAll('.book-item');
      const subcategoryTags = document.querySelectorAll('.design-subcategory-tag');
      
      // Update active tag
      subcategoryTags.forEach(function(tag) {
        tag.classList.remove('active');
        if (tag.textContent.toLowerCase().includes(genre) || (genre === 'all' && tag.textContent.includes('All Non-Fiction'))) {
          tag.classList.add('active');
        }
      });
      
      if (genre === 'all') {
        bookItems.forEach(function(book) {
          book.style.display = 'block';
        });
        return;
      }
      
      bookItems.forEach(function(book) {
        const bookGenre = book.getAttribute('data-genre');
        if (bookGenre === genre) {
          book.style.display = 'block';
        } else {
          book.style.display = 'none';
        }
      });
    }
  function orderNow(bookId, title) {
    const userData = JSON.parse(localStorage.getItem("user"));
    const userId = userData ? userData.id : 1; // fallback if not logged in

   
    window.location.href = "place-order.php?id=" + bookId + "&userId=" + userId;
}


    // Theme toggle functionality
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        themeBtn.textContent = document.body.classList.contains('dark-mode') ? 'Light Mode' : 'Dark Mode';
      });

      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
        themeBtn.textContent = 'Light Mode';
      }
    }

    // Initialize when page loads
    document.addEventListener('DOMContentLoaded', function() {
      if (window.location.pathname.includes('design.html')) {
        initializeDesignPage();
      }
      
      // Update search input placeholder for design page
      const searchInput = document.getElementById('search-input');
      if (searchInput && window.location.pathname.includes('design.html')) {
        searchInput.placeholder = "Search design books, authors, or topics...";
      }
    });
  </script>
</body>
</html>