<?php
include "connect.php";



$subQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subResult = mysqli_query($conn, $subQuery);
$categories = [];

if (mysqli_num_rows($subResult) > 0) {
    while ($row = mysqli_fetch_assoc($subResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categories[] = $row;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Categories - Online Book Store</title>
  
    <link rel="stylesheet" href="categories.css" />
  </head>

  <body>
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="logo">
        <img src="images/logo2.jpg" alt="Book Store Logo" />
        <h2>BOOKSTORE</h2>
      </div>

      <nav class="nav-links">
        <a href="index.html">Home</a>
        <div class="dropdown">
          <a href="categories.php" class="dropbtn active">Categories ▼</a>
          <div class="dropdown-content">
             <?php
foreach ($categories as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
          </div>
        </div>
         <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
      </nav>
    </aside>

    <!--Main Content -->
    <div class="main-content">
      <div class="topbar">
        <div class="search-container">
          <input
            id="search-input"
            type="text"
            placeholder="Search categories..."
          />
          <button onclick="searchSite()">Search</button>
        </div>
        <button id="theme-toggle">Dark Mode</button>
      </div>

      <!-- Categories Intro -->
      <section class="categories-intro">
        <h2>Browse Our Book Categories</h2>
        <hr />
        <p>
          Explore our extensive collection of books across various genres. Find
          your next favorite read from our carefully curated categories.
        </p>

        <!-- Quick Category Links -->
        <div class="quick-links">
         <?php
foreach ($categories as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" class="quick-link"><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </section>

      <!-- Categories Grid -->
       <section class="categories-grid-section">
    <h2>All Categories</h2>
    <div class="categories-container">
        <?php
foreach ($categories as $sub) {
    $subName = $sub['name'];
    $subDescription = $sub['description'];
    $bookCount = $sub['book_count'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<div class="category-card" onclick="navigateToCategory('<?php echo $subSlug; ?>.php')">
    <div class="category-icon">📚</div>
    <div class="category-info">
        <h3><?php echo $subName; ?></h3>
        <p><?php echo $subDescription; ?></p>
        <span class="book-count"><?php echo number_format($bookCount); ?> Books</span>
    </div>
    <div class="category-arrow">→</div>
</div>
<?php } ?>

    </div> 
</section>

      

      <!-- Newsletter Subscription -->
      <section class="newsletter-section">
        <div class="newsletter-container">
          <div class="newsletter-content">
            <h2>Stay Updated with New Arrivals</h2>
            <p>
              Subscribe to our newsletter and be the first to know about new
              book releases and exclusive offers.
            </p>

            <form id="newsletterForm" class="newsletter-form">
              <div class="form-group">
                <input
                  type="email"
                  id="newsletterEmail"
                  placeholder="Enter your email address"
                  required
                />
                <button type="submit" class="subscribe-btn">Subscribe</button>
              </div>
            </form>

            <div id="newsletterMessage" class="newsletter-message"></div>
          </div>
        </div>
      </section>

      <!--Footer-->
      <footer class="footer">
        <p>© 2025 Online Book Store. All rights reserved.</p>
        <div class="social-icons">
          <a href="https://www.facebook.com" target="_blank">
            <img src="images/Facebook.jpg" alt="Facebook" />
          </a>
          <a href="https://www.instagram.com" target="_blank">
            <img src="images/instagram.jpg" alt="Instagram" />
          </a>
          <a href="https://www.youtube.com" target="_blank">
            <img src="images/youtube.png" alt="YouTube" />
          </a>
        </div>
      </footer>
    </div>

    <script>
       const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
      // Navigation function
      function navigateToCategory(page) {
        window.location.href = page;
      }

      // Search functionality
      function searchSite() {
        const searchInput = document.getElementById("search-input");
        if (!searchInput || !searchInput.value.trim()) {
          showPopup("Please type something to search!");
          return;
        }

        const query = searchInput.value.toLowerCase().trim();
        const categoryCards = document.querySelectorAll(".category-card");

        let found = false;
        categoryCards.forEach(function (card) {
          const title = card.querySelector("h3").textContent.toLowerCase();
          const description = card.querySelector("p").textContent.toLowerCase();

          if (title.includes(query) || description.includes(query)) {
            card.style.display = "flex";
            found = true;
          } else {
            card.style.display = "none";
          }
        });

        if (!found) {
          showPopup("No categories found for: " + query);
        }
      }

      // Newsletter subscription
      document
        .getElementById("newsletterForm")
        .addEventListener("submit", function (e) {
          e.preventDefault();
          const email = document.getElementById("newsletterEmail").value.trim();
          const message = document.getElementById("newsletterMessage");

          if (email && validateEmail(email)) {
            // Store subscription in localStorage
            let subscriptions =
              JSON.parse(localStorage.getItem("newsletterSubscriptions")) || [];
            if (!subscriptions.includes(email)) {
              subscriptions.push(email);
              localStorage.setItem(
                "newsletterSubscriptions",
                JSON.stringify(subscriptions)
              );
            }

            message.textContent =
              "Thank you for subscribing to our newsletter!";
            message.style.color = "#90EE90";
            document.getElementById("newsletterEmail").value = "";

            // Clear message after 3 seconds
            setTimeout(function () {
              message.textContent = "";
            }, 3000);
          } else {
            message.textContent = "Please enter a valid email address.";
            message.style.color = "#FF6B6B";
          }
        });

      // Utility functions
      function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
      }

      function showPopup(message) {
        const existingPopup = document.querySelector(".custom-popup");
        if (existingPopup) {
          existingPopup.remove();
        }

        const popup = document.createElement("div");
        popup.className = "custom-popup";
        popup.style.cssText =
          "position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,0.9); color: white; padding: 20px 30px; border-radius: 10px; z-index: 10000; font-size: 16px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.3); min-width: 250px;";
        popup.textContent = message;

        document.body.appendChild(popup);

        setTimeout(function () {
          if (document.body.contains(popup)) {
            document.body.removeChild(popup);
          }
        }, 2000);
      }

      // Theme toggle functionality
      const themeBtn = document.getElementById("theme-toggle");
      if (themeBtn) {
        themeBtn.addEventListener("click", function () {
          document.body.classList.toggle("dark-mode");
          localStorage.setItem(
            "theme",
            document.body.classList.contains("dark-mode") ? "dark" : "light"
          );
          themeBtn.textContent = document.body.classList.contains("dark-mode")
            ? "Light Mode"
            : "Dark Mode";
        });

        if (localStorage.getItem("theme") === "dark") {
          document.body.classList.add("dark-mode");
          themeBtn.textContent = "Light Mode";
        }
      }

      // Add event listener for Enter key in search
      document
        .getElementById("search-input")
        .addEventListener("keyup", function (event) {
          if (event.key === "Enter") {
            searchSite();
          }
        });

      // Initialize page
      document.addEventListener("DOMContentLoaded", function () {
        // Set initial theme
        if (localStorage.getItem("theme") === "dark") {
          document.body.classList.add("dark-mode");
          if (themeBtn) {
            themeBtn.textContent = "Light Mode";
          }
        }
      });
    </script>
  </body>
</html>
