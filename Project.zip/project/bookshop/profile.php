<?php
include "connect.php";
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];

// Get user details
$userQuery = "SELECT * FROM users WHERE id = $user_id";
$userResult = mysqli_query($conn, $userQuery);
$user = mysqli_fetch_assoc($userResult);

// Get categories for sidebar
$subCategoryQuery = "SELECT * FROM categories ORDER BY id ASC";
$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];
        $categoriesList[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Online Book Store</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Same sidebar as index.php -->
    <aside class="sidebar">
        <div class="logo">
            <img src="images/logo2.jpg" alt="Book Store Logo" />
            <h2>BOOKSTORE</h2>
        </div>
        <nav class="nav-links">
            <a href="index.php">Home</a>
            <div class="dropdown">
                <a href="categories.php" class="dropbtn">Categories ▼</a>
                <div class="dropdown-content">
                    <?php foreach ($categoriesList as $sub): ?>
                        <a href="<?php echo strtolower(str_replace(' ', '-', $sub['name'])); ?>.php">
                            <?php echo $sub['name']; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <a href="orders.php">Orders</a>
            <a href="cart.php">Cart</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
        </nav>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="search-container">
                <input id="search-input" type="text" placeholder="Search..." />
                <button onclick="searchSite()">Search</button>
            </div>
            <button id="theme-toggle">Dark Mode</button>
            
            <div class="profile-option">
                <a href="profile.php" class="profile-link">
                    <span class="profile-icon">👤</span>
                    <span><?php echo $user_name; ?></span>
                </a>
                <a href="logout.php" class="profile-link" style="margin-left: 10px;">
                    <span>Logout</span>
                </a>
            </div>
        </header>

        <div class="profile-container">
            <h1>My Profile</h1>
            <div class="profile-info">
                <div class="info-item">
                    <strong>Name:</strong> <?php echo $user['name']; ?>
                </div>
                <div class="info-item">
                    <strong>Email:</strong> <?php echo $user['email']; ?>
                </div>
                <div class="info-item">
                    <strong>Phone:</strong> <?php echo $user['phone'] ?: 'Not provided'; ?>
                </div>
                <div class="info-item">
                    <strong>Member Since:</strong> <?php echo date('F j, Y', strtotime($user['created_at'])); ?>
                </div>
            </div>
        </div>
    </main>

    <script src="script.js"></script>
</body>
</html>