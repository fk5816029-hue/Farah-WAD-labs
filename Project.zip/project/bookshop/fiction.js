
      const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
    // Theme Toggle
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        themeBtn.textContent = document.body.classList.contains('dark-mode') ? 'Light Mode' : 'Dark Mode';
      });

      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
        themeBtn.textContent = 'Light Mode';
      }
    }

    // Search Function for Fiction Books
    function searchSite() {
      const input = document.getElementById('search-input');
      if (!input || !input.value.trim()) {
        showPopup('Please type something to search!');
        return;
      }
      
      const query = input.value.toLowerCase().trim();
      const bookItems = document.querySelectorAll('.book-item');
      
      let found = false;
      bookItems.forEach(function(book) {
        const title = book.querySelector('h4').textContent.toLowerCase();
        const author = book.querySelector('.book-author').textContent.toLowerCase();
        const description = book.querySelector('.book-description').textContent.toLowerCase();
        
        if (title.includes(query) || author.includes(query) || description.includes(query)) {
          book.style.display = 'block';
          found = true;
        } else {
          book.style.display = 'none';
        }
      });
      
      if (!found) {
        showPopup('No fiction books found for: ' + query);
      }
    }
function removeSlug(genre) {
  return genre.replace(/-/g, ' ');
}
    // Filter Books by Genre
    function filterBooks(genre) {
      genre = removeSlug(genre);
      const bookItems = document.querySelectorAll('.book-item');
      const subcategoryTags = document.querySelectorAll('.subcategory-tag');
      
      // Update active tag
      subcategoryTags.forEach(function(tag) {
        tag.classList.remove('active');
        if (tag.textContent.toLowerCase().includes(genre) || (genre === 'all' && tag.textContent.includes('All Fiction'))) {
          tag.classList.add('active');
        }
      });
      
      if (genre === 'all') {
        bookItems.forEach(function(book) {
          book.style.display = 'block';
        });
        return;
      }
      
      bookItems.forEach(function(book) {
        const bookGenre = book.getAttribute('data-genre');
        console.log('bookGenre: ', bookGenre);
        if (bookGenre === genre) {
          book.style.display = 'block';
        } else {
          book.style.display = 'none';
        }
      });
    }
     function orderNow(bookId, title) {
    const userData = JSON.parse(localStorage.getItem("user"));
    const userId = userData ? userData.id : 1; // fallback if not logged in

   
    window.location.href = "place-order.php?id=" + bookId + "&userId=" + userId;
}

    // Cart and Wishlist functionality
    function addToCart(bookId, bookTitle, bookPrice) {
      let cart = JSON.parse(localStorage.getItem('bookCart')) || [];
      const existingItem = cart.find(function(item) {
        return item.id === bookId;
      });
      
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push({
          id: bookId,
          title: bookTitle,
          price: bookPrice,
          quantity: 1,
          dateAdded: new Date().toISOString()
        });
      }
      
      localStorage.setItem('bookCart', JSON.stringify(cart));
      let user = localStorage.getItem('user');
let userId = 1; // default if not logged in

if (user) {
    try {
        let userObj = JSON.parse(user);
        if (userObj.id) {
            userId = userObj.id;
        }
    } catch (e) {
        console.error("Error parsing user from localStorage:", e);
    }
}
      let formData = new FormData();
      console.log('bookId: ', bookId);
    formData.append('bookId', bookId);
    formData.append('quantity', 1);
    console.log('userId: ', userId);
    formData.append('userId', userId);

    fetch('add-to-cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        showPopup(`${bookTitle} added to cart!`);
        console.log(data);
    })
    .catch(err => {
        console.error(err);
        console.error(err.message);
        showPopup(`Error adding ${bookTitle} to cart.`);
    });
    }

    function addToWishlist(bookId, bookTitle) {
      let wishlist = JSON.parse(localStorage.getItem('bookWishlist')) || [];
      const existingIndex = wishlist.findIndex(function(item) {
        return item.id === bookId;
      });
      
      if (existingIndex > -1) {
        wishlist.splice(existingIndex, 1);
        showPopup(bookTitle + ' removed from wishlist');
      } else {
        wishlist.push({
          id: bookId,
          title: bookTitle,
          dateAdded: new Date().toISOString()
        });
        showPopup(bookTitle + ' added to wishlist!');
      }
      
      localStorage.setItem('bookWishlist', JSON.stringify(wishlist));
    }

    // Utility functions
    function showPopup(message) {
      const existingPopup = document.querySelector('.custom-popup');
      if (existingPopup) {
        existingPopup.remove();
      }
      
      const popup = document.createElement('div');
      popup.className = 'custom-popup';
      popup.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,0.9); color: white; padding: 20px 30px; border-radius: 10px; z-index: 10000; font-size: 16px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.3); min-width: 250px;';
      popup.textContent = message;
      
      document.body.appendChild(popup);
      
      setTimeout(function() {
        if (document.body.contains(popup)) {
          document.body.removeChild(popup);
        }
      }, 2000);
    }

    // Add event listener for Enter key in search
    document.getElementById('search-input').addEventListener('keyup', function(event) {
      if (event.key === 'Enter') {
        searchSite();
      }
    });

    // Initialize page
    document.addEventListener('DOMContentLoaded', function() {
      // Set initial theme
      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
        if (themeBtn) {
          themeBtn.textContent = 'Light Mode';
        }
      }
    });
