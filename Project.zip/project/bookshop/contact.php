<?php
include "connect.php";
$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact Us - Online Book Store</title>
  <style>
    /* Base Styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
        display: flex;
        background-color: #f5f7fa;
        color: #333;
        transition: background-color 0.3s, color 0.3s;
        min-height: 100vh;
    }

    /* Sidebar Styles */
    .sidebar {
        width: 250px;
        height: 100vh;
        background: linear-gradient(180deg, #2c3e50, #1a2530);
        color: white;
        padding: 20px;
        position: fixed;
        overflow-y: auto;
        left: 0;
    }

    .logo {
        display: flex;
        align-items: center;
        margin-bottom: 30px;
    }

    .logo img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin-right: 10px;
    }

    .logo h2 {
        font-size: 1.2rem;
        font-weight: 600;
    }

    .nav-links {
        display: flex;
        flex-direction: column;
    }

    .nav-links a {
        color: #ecf0f1;
        text-decoration: none;
        padding: 12px 15px;
        margin: 5px 0;
        border-radius: 5px;
        transition: all 0.3s;
    }

    .nav-links a:hover, .nav-links a.active {
        background-color: #3498db;
        color: white;
    }

    .dropdown {
        position: relative;
         margin: 5px 0;
      padding:12px 0px;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        left: 100%;
        top: 0;
        background-color: #34495e;
        min-width: 200px;
        border-radius: 5px;
        box-shadow: 0 8px 16px rgba(0,0,0,0.2);
        z-index: 1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown-content a {
        display: block;
        padding: 10px 15px;
    }

    /* Main Content Styles */
    .main-content {
        flex: 1;
        margin-left: 250px;
        padding: 20px;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    .topbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        padding: 15px 20px;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .search-container {
        display: flex;
        gap: 10px;
    }

    .search-container input {
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        width: 300px;
        font-size: 1rem;
    }

    .search-container button, #theme-toggle {
        padding: 10px 20px;
        background-color: #3498db;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
        font-size: 1rem;
    }

    .search-container button:hover, #theme-toggle:hover {
        background-color: #2980b9;
    }

    .profile-option {
        display: flex;
        align-items: center;
    }

    .profile-link {
        display: flex;
        align-items: center;
        text-decoration: none;
        color: #333;
        padding: 8px 15px;
        border-radius: 5px;
        transition: background-color 0.3s;
    }

    .profile-link:hover {
        background-color: #f0f0f0;
    }

    .profile-icon {
        font-size: 1.5rem;
        margin-right: 8px;
    }

    /* Contact Hero Section */
    .contact-hero {
        text-align: center;
        padding: 50px 40px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 15px;
        margin-bottom: 40px;
    }

    .contact-hero h1 {
        font-size: 2.5rem;
        margin-bottom: 15px;
        font-weight: 700;
    }

    .contact-hero p {
        font-size: 1.2rem;
        max-width: 600px;
        margin: 0 auto;
        line-height: 1.6;
        opacity: 0.95;
    }

    /* Contact Content */
    .contact-content {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 40px;
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    /* Contact Info Section */
    .contact-info-section {
        background: white;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }

    .contact-info-section h2 {
        color: #2c3e50;
        margin-bottom: 30px;
        font-size: 1.8rem;
        font-weight: 600;
    }

    .contact-info-grid {
        display: flex;
        flex-direction: column;
        gap: 25px;
    }

    .contact-item {
        display: flex;
        align-items: flex-start;
        gap: 15px;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 10px;
        transition: all 0.3s ease;
    }

    .contact-item:hover {
        background: #e9ecef;
        transform: translateX(5px);
    }

    .contact-icon {
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, #3498db, #2ecc71);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.3rem;
        color: white;
        flex-shrink: 0;
    }

    .contact-details h3 {
        color: #2c3e50;
        margin-bottom: 5px;
        font-size: 1.1rem;
    }

    .contact-details p {
        color: #666;
        margin: 0;
        line-height: 1.5;
    }

    /* Business Hours */
    .business-hours {
        margin-top: 30px;
        padding: 25px;
        background: #f8f9fa;
        border-radius: 10px;
        border-left: 4px solid #3498db;
    }

    .business-hours h3 {
        color: #2c3e50;
        margin-bottom: 15px;
        font-size: 1.2rem;
    }

    .hours-list {
        list-style: none;
    }

    .hours-list li {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid #e9ecef;
    }

    .hours-list li:last-child {
        border-bottom: none;
    }

    .day {
        color: #2c3e50;
        font-weight: 500;
    }

    .time {
        color: #666;
    }

    /* Contact Form Section */
    .contact-form-section {
        background: white;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }

    .contact-form-section h2 {
        color: #2c3e50;
        margin-bottom: 30px;
        font-size: 1.8rem;
        font-weight: 600;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #2c3e50;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #f8f9fa;
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
        outline: none;
        border-color: #3498db;
        background: white;
        box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
    }

    .form-group textarea {
        resize: vertical;
        min-height: 120px;
    }

    .submit-btn {
        background: linear-gradient(135deg, #3498db, #2980b9);
        color: white;
        border: none;
        padding: 15px 30px;
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 100%;
        margin-top: 10px;
    }

    .submit-btn:hover {
        background: linear-gradient(135deg, #2980b9, #3498db);
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(52, 152, 219, 0.3);
    }

    /* Message Styling */
    .message {
        margin-top: 20px;
        padding: 15px;
        border-radius: 8px;
        text-align: center;
        font-weight: 500;
        display: none;
    }

    .message.success {
        background: #d1fae5;
        color: #065f46;
        border: 1px solid #a7f3d0;
        display: block;
    }

    .message.error {
        background: #fee2e2;
        color: #991b1b;
        border: 1px solid #fecaca;
        display: block;
    }

    /* Footer */
    .footer {
        background: linear-gradient(135deg, #2c3e50, #34495e);
        color: white;
        padding: 40px 30px;
        border-radius: 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 50px;
    }

    .footer p {
        font-size: 1rem;
        margin: 0;
    }

    .social-icons {
        display: flex;
        gap: 15px;
    }

    .social-icons a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
        transition: all 0.3s ease;
    }

    .social-icons a:hover {
        background: #3498db;
        transform: translateY(-3px);
    }

    .social-icons img {
        width: 20px;
        height: 20px;
        border-radius: 50%;
    }

    /* Dark Mode Styles */
    body.dark-mode {
        background-color: #1a1a2e;
        color: #e6e6e6;
    }

    body.dark-mode .topbar,
    body.dark-mode .contact-info-section,
    body.dark-mode .contact-form-section {
        background-color: #16213e;
        color: #e6e6e6;
        border-color: #0f3460;
    }

    body.dark-mode .search-container input {
        background-color: #0f3460;
        border-color: #1a3a5f;
        color: #e6e6e6;
    }

    body.dark-mode .profile-link {
        color: #e6e6e6;
    }

    body.dark-mode .profile-link:hover {
        background-color: #0f3460;
    }

    body.dark-mode .contact-info-section h2,
    body.dark-mode .contact-form-section h2 {
        color: #e6e6e6;
    }

    body.dark-mode .contact-item {
        background: #1e2a47;
    }

    body.dark-mode .contact-item:hover {
        background: #2d3748;
    }

    body.dark-mode .contact-details h3 {
        color: #e6e6e6;
    }

    body.dark-mode .contact-details p {
        color: #d1d5db;
    }

    body.dark-mode .business-hours {
        background: #1e2a47;
    }

    body.dark-mode .business-hours h3 {
        color: #e6e6e6;
    }

    body.dark-mode .day {
        color: #e6e6e6;
    }

    body.dark-mode .time {
        color: #d1d5db;
    }

    body.dark-mode .form-group label {
        color: #e6e6e6;
    }

    body.dark-mode .form-group input,
    body.dark-mode .form-group select,
    body.dark-mode .form-group textarea {
        background: #0f3460;
        border-color: #1a3a5f;
        color: #e6e6e6;
    }

    body.dark-mode .form-group input:focus,
    body.dark-mode .form-group select:focus,
    body.dark-mode .form-group textarea:focus {
        background: #0f3460;
        border-color: #3498db;
    }

    body.dark-mode .footer {
        background: linear-gradient(135deg, #1a2530, #2c3e50);
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .contact-content {
            grid-template-columns: 1fr;
            gap: 30px;
        }
    }

    @media (max-width: 768px) {
        .sidebar {
            width: 70px;
            padding: 15px 10px;
        }
        
        .logo h2 {
            display: none;
        }
        
        .main-content {
            margin-left: 70px;
            padding: 15px;
        }
        
        .topbar {
            flex-direction: column;
            gap: 15px;
            padding: 20px;
        }
        
        .search-container {
            width: 100%;
        }
        
        .search-container input {
            width: 100%;
        }
        
        .contact-hero {
            padding: 40px 20px;
        }
        
        .contact-hero h1 {
            font-size: 2rem;
        }
        
        .contact-hero p {
            font-size: 1rem;
        }
        
        .contact-info-section,
        .contact-form-section {
            padding: 30px 25px;
        }
        
        .footer {
            flex-direction: column;
            gap: 20px;
            text-align: center;
            padding: 30px 20px;
        }
    }

    @media (max-width: 480px) {
        .sidebar {
            display: none;
        }
        
        .main-content {
            margin-left: 0;
        }
        
        .contact-hero {
            padding: 30px 15px;
        }
        
        .contact-hero h1 {
            font-size: 1.8rem;
        }
        
        .contact-info-section,
        .contact-form-section {
            padding: 25px 20px;
        }
        
        .contact-item {
            padding: 15px;
        }
    }
  </style>
</head>
<body>
  <!--SideBar-->
  <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.html">Home</a>
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
         <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
        <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
      <a href="about.php">About</a>
      <a href="contact.php" class="active">Contact</a>
    </nav>
  </aside>

  <!--Main Section-->
  <main class="main-content">
    <header class="topbar">
      <div class="search-container">
        <input id="search-input" type="text" placeholder="Search..." />
        <button onclick="searchSite()">Search</button>
      </div>
      <button id="theme-toggle">Dark Mode</button>
      
      <!-- Profile Option in Topbar -->
      <div class="profile-option">
        <a href="registration.html" class="profile-link">
          <span class="profile-icon">👤</span>
        </a>
      </div>
    </header>

    <!-- Contact Hero Section -->
    <section class="contact-hero">
      <h1>Contact Us</h1>
      <p>We're here to help! Get in touch with us for any questions, book recommendations, or support.</p>
    </section>

    <!-- Contact Content -->
    <div class="contact-content">
      <!-- Contact Information -->
      <div class="contact-info-section">
        <h2>Get In Touch</h2>
        <div class="contact-info-grid">
          <div class="contact-item">
            <div class="contact-icon">📧</div>
            <div class="contact-details">
              <h3>Email</h3>
              <p>info@bookstore.com<br>support@bookstore.com</p>
            </div>
          </div>
          
          <div class="contact-item">
            <div class="contact-icon">📞</div>
            <div class="contact-details">
              <h3>Phone</h3>
              <p>+92 300 1234567<br>+92 21 1234567</p>
            </div>
          </div>
          
          <div class="contact-item">
            <div class="contact-icon">📍</div>
            <div class="contact-details">
              <h3>Address</h3>
              <p>123 Book Street, Reading Area<br>Karachi, Pakistan 75500</p>
            </div>
          </div>
          
          <div class="contact-item">
            <div class="contact-icon">💬</div>
            <div class="contact-details">
              <h3>Live Chat</h3>
              <p>Available 24/7 for quick assistance</p>
            </div>
          </div>
        </div>

        <!-- Business Hours -->
        <div class="business-hours">
          <h3>Business Hours</h3>
          <ul class="hours-list">
            <li>
              <span class="day">Monday - Friday</span>
              <span class="time">9:00 AM - 8:00 PM</span>
            </li>
            <li>
              <span class="day">Saturday</span>
              <span class="time">10:00 AM - 6:00 PM</span>
            </li>
            <li>
              <span class="day">Sunday</span>
              <span class="time">12:00 PM - 5:00 PM</span>
            </li>
          </ul>
        </div>
      </div>

      <!-- Contact Form -->
      <div class="contact-form-section">
        <h2>Send Us a Message</h2>
        <form id="contactForm">
          <div class="form-group">
            <label for="name">Full Name *</label>
            <input type="text" id="name" placeholder="Enter your full name" required>
          </div>

          <div class="form-group">
            <label for="email">Email Address *</label>
            <input type="email" id="email" placeholder="Enter your email" required>
          </div>

          <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" placeholder="Enter your phone number">
          </div>

          <div class="form-group">
            <label for="subject">Subject *</label>
            <select id="subject" required>
              <option value="">Select a subject</option>
              <option value="general">General Inquiry</option>
              <option value="order">Order Support</option>
              <option value="book">Book Recommendation</option>
              <option value="technical">Technical Support</option>
              <option value="feedback">Feedback</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div class="form-group">
            <label for="message">Message *</label>
            <textarea id="message" placeholder="Type your message here..." required></textarea>
          </div>

          <button type="submit" class="submit-btn">Send Message</button>
        </form>

        <div id="contactMessage" class="message"></div>
      </div>
    </div>

    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank">
          <img src="images/Facebook.jpg" alt="Facebook">
        </a>
        <a href="https://www.instagram.com" target="_blank">
          <img src="images/instagram.jpg" alt="Instagram">
        </a>
        <a href="https://www.youtube.com" target="_blank">
          <img src="images/youtube.png" alt="YouTube">
        </a>
      </div>
    </footer>
  </main>

  <script>
      const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
    // Theme Toggle
    document.addEventListener('DOMContentLoaded', function() {
        const themeToggle = document.getElementById('theme-toggle');
        
        if (themeToggle) {
            // Check for saved theme preference
            const savedTheme = localStorage.getItem('theme') || 
                (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            
            // Apply the saved theme
            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                themeToggle.textContent = 'Light Mode';
            }
            
            // Toggle theme when button is clicked
            themeToggle.addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                
                if (document.body.classList.contains('dark-mode')) {
                    localStorage.setItem('theme', 'dark');
                    themeToggle.textContent = 'Light Mode';
                } else {
                    localStorage.setItem('theme', 'light');
                    themeToggle.textContent = 'Dark Mode';
                }
            });
        }
    });

    // Contact Form Submission
    document.addEventListener('DOMContentLoaded', function() {
        const contactForm = document.getElementById('contactForm');
        const contactMessage = document.getElementById('contactMessage');
        
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Get form values
                const name = document.getElementById('name').value.trim();
                const email = document.getElementById('email').value.trim();
                const phone = document.getElementById('phone').value.trim();
                const subject = document.getElementById('subject').value;
                const message = document.getElementById('message').value.trim();
                
                // Basic validation
                if (!name || !email || !subject || !message) {
                    showMessage('Please fill all required fields.', 'error');
                    return;
                }
                
                if (!validateEmail(email)) {
                    showMessage('Please enter a valid email address.', 'error');
                    return;
                }
                
                // Simulate form submission
                showMessage('Thank you for your message! We will get back to you within 24 hours.', 'success');
                
                // Reset form
                contactForm.reset();
                
                // Auto-hide success message
                setTimeout(() => {
                    contactMessage.style.display = 'none';
                }, 5000);
            });
        }
        
        function showMessage(text, type) {
            contactMessage.textContent = text;
            contactMessage.className = 'message ' + type;
        }
        
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
    });

    // Search Functionality
    function searchSite() {
        const searchInput = document.getElementById('search-input');
        if (!searchInput) return;
        
        const searchTerm = searchInput.value.trim();
        
        if (!searchTerm) {
            showPopup('Please enter a search term');
            return;
        }
        
        // Simple search implementation for contact page
        const searchableContent = [
            'contact', 'email', 'phone', 'address', 'support',
            'message', 'help', 'inquiry', 'business hours'
        ];
        
        const found = searchableContent.some(term => 
            term.includes(searchTerm.toLowerCase()) || searchTerm.toLowerCase().includes(term)
        );
        
        if (found) {
            highlightSearchTerms(searchTerm);
            showPopup('Search results found in contact page');
        } else {
            showPopup('No search results found for: ' + searchTerm);
        }
    }

    function highlightSearchTerms(term) {
        const elements = document.querySelectorAll('h1, h2, h3, p, label, .contact-details p');
        elements.forEach(element => {
            const html = element.innerHTML;
            const regex = new RegExp(`(${term})`, 'gi');
            const newHtml = html.replace(regex, '<mark style="background-color: yellow; color: black;">$1</mark>');
            element.innerHTML = newHtml;
        });
    }

    function showPopup(message) {
        // Remove existing popup if any
        const existingPopup = document.querySelector('.custom-popup');
        if (existingPopup) {
            existingPopup.remove();
        }
        
        const popup = document.createElement('div');
        popup.className = 'custom-popup';
        popup.textContent = message;
        popup.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0,0,0,0.9);
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            z-index: 10000;
            font-size: 16px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            min-width: 250px;
        `;
        
        document.body.appendChild(popup);
        
        setTimeout(function() {
            if (document.body.contains(popup)) {
                document.body.removeChild(popup);
            }
        }, 2000);
    }

    // Add keyboard support for search
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('search-input');
        
        if (searchInput) {
            searchInput.addEventListener('keyup', function(event) {
                if (event.key === 'Enter') {
                    searchSite();
                }
            });
        }
    });

    // Add animations to contact items
    document.addEventListener('DOMContentLoaded', function() {
        const contactItems = document.querySelectorAll('.contact-item');
        contactItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateX(-20px)';
            item.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            
            setTimeout(() => {
                item.style.opacity = '1';
                item.style.transform = 'translateX(0)';
            }, 300 + (index * 100));
        });
        
        // Animate form
        const contactFormSection = document.querySelector('.contact-form-section');
        if (contactFormSection) {
            contactFormSection.style.opacity = '0';
            contactFormSection.style.transform = 'translateY(30px)';
            contactFormSection.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            
            setTimeout(() => {
                contactFormSection.style.opacity = '1';
                contactFormSection.style.transform = 'translateY(0)';
            }, 800);
        }
    });

    // Form input validation styling
    document.addEventListener('DOMContentLoaded', function() {
        const formInputs = document.querySelectorAll('input, select, textarea');
        
        formInputs.forEach(input => {
            input.addEventListener('blur', function() {
                if (this.value.trim() === '' && this.hasAttribute('required')) {
                    this.style.borderColor = '#ef4444';
                } else {
                    this.style.borderColor = '#e9ecef';
                }
            });
            
            input.addEventListener('input', function() {
                if (this.value.trim() !== '') {
                    this.style.borderColor = '#3498db';
                }
            });
        });
    });
  </script>
</body>
</html>