<?php
include "connect.php";

$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}

// ---- UPDATED LOGIC: DO NOT DEFAULT TO USER 1 ----
$items = []; // Initialize empty items array

if (isset($_GET['userId'])) {
    $userId = intval($_GET['userId']);

    // ---- GET CART USING user_id ----
    $cartQuery = "SELECT * FROM carts WHERE user_id = $userId LIMIT 1";
    $cartResult = mysqli_query($conn, $cartQuery);

    // Only proceed if a cart exists
    if (mysqli_num_rows($cartResult) > 0) {
        $cart = mysqli_fetch_assoc($cartResult);
        $cartId = $cart['id'];

        // ---- GET CART ITEMS WITH BOOK DETAILS ----
        $itemQuery = "
            SELECT 
                cart_items.*, 
                books.title, 
                books.description, 
                books.cover_image, 
                books.price,
                books.publisher,
                books.rating,
                subcategories.name AS genre
            FROM cart_items
            JOIN books ON books.id = cart_items.book_id
            LEFT JOIN subcategories ON subcategories.id = books.subcategory_id
            WHERE cart_items.cart_id = $cartId
        ";

        $itemResult = mysqli_query($conn, $itemQuery);

        while ($row = mysqli_fetch_assoc($itemResult)) {
            $items[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Non-Fiction Books - Online Book Store</title>
  <style>
    /* Base styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .star-rating{
 display: flex;
    align-items: center;
    gap: 6px; /* space between stars and text */
    }
    .rating-text{
        margin-bottom:5px;
        color:#555;
    }
     .star {
        width: 15px;
        height: 15px;
        margin-bottom: 5px;
        display: inline-block;
        background: url('data:image/svg+xml;utf8,<svg fill="none" stroke="%23f1c40f" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><polygon points="12,2 15,9 22,9 17,14 19,21 12,17 5,21 7,14 2,9 9,9"/></svg>') no-repeat center;
        background-size: contain;
        margin-right: 3px;
    }

    .star.filled {
      width: 18px;
        height: 18px;
        background: url('data:image/svg+xml;utf8,<svg fill="%23f1c40f" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><polygon points="12,2 15,9 22,9 17,14 19,21 12,17 5,21 7,14 2,9 9,9"/></svg>') no-repeat center;
        background-size: contain;
    }
    body {
      display: flex;
      background-color: #f5f7fa;
      color: #333;
      transition: background-color 0.3s, color 0.3s;
    }

    /* Sidebar styles */
    .sidebar {
      width: 250px;
      height: 100vh;
      background: linear-gradient(180deg, #2c3e50, #1a2530);
      color: white;
      padding: 20px;
      position: fixed;
      overflow-y: auto;
    }

    .logo {
      display: flex;
      align-items: center;
      margin-bottom: 30px;
    }

    .logo img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      margin-right: 10px;
    }

    .logo h2 {
      font-size: 1.2rem;
      font-weight: 600;
    }

    .nav-links {
      display: flex;
      flex-direction: column;
    }

    .nav-links a {
      color: #ecf0f1;
      text-decoration: none;
      padding: 12px 15px;
      margin: 5px 0;
      border-radius: 5px;
      transition: all 0.3s;
    }

    .nav-links a:hover, .nav-links a.active {
      background-color: #3498db;
      color: white;
    }

    .dropdown {
      position: relative;
      margin: 5px 0;
      padding:12px 0px;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      left: 0%;
      top: 120%;
      background-color: #34495e;
      min-width: 200px;
      border-radius: 5px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.2);
      z-index: 1;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown-content a {
      display: block;
      padding: 10px 15px;
    }

    /* Main content styles */
    .main-content {
      flex: 1;
      margin-left: 250px;
      padding: 20px;
    }

    .topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
      padding: 15px 20px;
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .search-container {
      display: flex;
      gap: 10px;
    }

    .search-container input {
      padding: 10px 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      width: 300px;
    }

    .search-container button, #theme-toggle {
      padding: 10px 20px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .search-container button:hover, #theme-toggle:hover {
      background-color: #2980b9;
    }

    /* Hero section */
    .hero {
      background: linear-gradient(135deg, #3498db, #8e44ad);
      color: white;
      padding: 40px;
      border-radius: 10px;
      margin-bottom: 30px;
      text-align: center;
    }

    .hero h1 {
      font-size: 2.5rem;
      margin-bottom: 15px;
    }

    .hero p {
      font-size: 1.2rem;
      max-width: 700px;
      margin: 0 auto;
    }

    /* Books Grid */
    .books-section {
      margin-bottom: 40px;
    }

    .books-section h2 {
      margin-bottom: 20px;
      font-size: 1.8rem;
      color: #2c3e50;
    }

    .books-content {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 25px;
    }

    .book-item {
      background-color: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .book-item:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .book-item h4 {
      padding: 15px 20px;
      /* background-color: #f8f9fa; */
      /* border-bottom: 1px solid #eee; */
      color: #2c3e50;
    }

    .book-cover {
      width: 100%;
      height: 200px;
      overflow: hidden;
      position: relative;
    }

    .book-cover img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.3s;
    }

    .book-item:hover .book-cover img {
      transform: scale(1.05);
    }

    .book-details {
      padding: 15px 20px;
    }

    .book-author {
      color: #7f8c8d;
      font-style: italic;
      margin-bottom: 10px;
    }

    .book-price {
      font-size: 1.2rem;
      font-weight: bold;
      color: #27ae60;
      margin-bottom: 0px;
    }

    .book-actions {
      display: flex;
      gap: 10px;
    }

    .btn {
      padding: 8px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
      flex: 1;
      text-align: center;
      text-decoration: none;
      font-size: 0.9rem;
    }

    .btn-primary {
      background-color: #3498db;
      color: white;
    }

    .btn-primary:hover {
      background-color: #2980b9;
    }

    .btn-secondary {
      background-color: #e74c3c;
      color: white;
    }

    .btn-secondary:hover {
      background-color: #c0392b;
    }

    /* Footer */
    .footer {
      background-color: #2c3e50;
      color: white;
      padding: 30px;
      border-radius: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .social-icons {
      display: flex;
      gap: 15px;
    }

    .social-icons img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      transition: transform 0.3s;
    }

    .social-icons img:hover {
      transform: scale(1.1);
    }

    /* Non-Fiction Subcategories */
    .nonfiction-subcategories {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 30px;
      border-radius: 15px;
      margin-bottom: 30px;
      color: white;
    }

    .nonfiction-subcategories h2 {
      text-align: center;
      margin-bottom: 25px;
      font-size: 1.8rem;
      color: white;
    }

    .subcategories-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
    }

    .subcategory-tag {
      background: rgba(255, 255, 255, 0.1);
      padding: 15px;
      border-radius: 10px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .subcategory-tag:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-3px);
    }

    .subcategory-tag.active {
      background: rgba(255, 255, 255, 0.3);
      border-color: rgba(255, 255, 255, 0.4);
    }

    /* Book Rating */
    .book-rating {
      color: #f39c12;
      margin-bottom: 10px;
      font-size: 0.9rem;
    }

    .book-description {
      color: #555;
      line-height: 1.5;
      margin-bottom: 15px;
      font-size: 0.9rem;
    }

    .book-genre {
      display: inline-block;
      background-color: #e8f4fc;
      color: #3498db;
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.8rem;
      margin-bottom: 10px;
    }

    /* Dark mode styles */
    body.dark-mode {
      background-color: #1a1a2e;
      color: #e6e6e6;
    }

    body.dark-mode .topbar,
    body.dark-mode .book-item {
      background-color: #16213e;
      color: #e6e6e6;
    }

    body.dark-mode .book-item h4 {
      background-color: #0f3460;
      color: #e6e6e6;
    }

    body.dark-mode .book-details {
      color: #b8b8b8;
    }

    body.dark-mode .search-container input {
      background-color: #16213e;
      border-color: #0f3460;
      color: #e6e6e6;
    }

    body.dark-mode .book-genre {
      background-color: #2c3e50;
      color: #3498db;
    }

    body.dark-mode .book-description {
      color: #b8b8b8;
    }

    /* Popup styles */
    .custom-popup {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(0,0,0,0.9);
      color: white;
      padding: 20px 30px;
      border-radius: 10px;
      z-index: 10000;
      font-size: 16px;
      text-align: center;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
      min-width: 250px;
    }
    .book-footer{
        display:flex;
        justify-content:space-between;  
    }
    .book-quantity{
        display:flex;
        align-items:center;
        gap:5px;
    }
    .hidden{
      display: none;
    }
    .qty-btn {
        background-color: #3498db;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .qty-btn:hover {
        background-color: #2980b9;
    }
    .qty-input {
        width: 50px;
        text-align: center;
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 5px;
    }
    .book-header{
        display:flex;
        justify-content:space-between;
        align-items:center;
    }
    .book-title-section{
        display:flex;
        align-items:center;
        gap:0px;
         padding:7px;
    }
    .book-title{
        padding-left:5px !important
    }
    .delete-btn{
        background-color:transparent;
        border:none;
        cursor:pointer;
        color:#e74c3c;
        font-weight:bold;
        padding:7px;
    }
    .order-btn{
        padding:10px 20px;
        background-color:#27ae60;
        color:white;
        border:none;
        border-radius:5px;
        cursor:pointer;
        font-size:1rem;
        transition:background-color 0.3s;
    }
    /* Responsive design */
    @media (max-width: 1024px) {
      .books-content {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      }
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
        padding: 15px 10px;
      }
      
      .logo h2 {
        display: none;
      }
      
      .main-content {
        margin-left: 70px;
      }
      
      .topbar {
        flex-direction: column;
        gap: 15px;
      }
      
      .search-container {
        width: 100%;
      }
      
      .search-container input {
        width: 100%;
      }
      
      .books-content {
        grid-template-columns: 1fr;
      }
      
      .subcategories-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .footer {
        flex-direction: column;
        gap: 20px;
        text-align: center;
      }
    }

    @media (max-width: 480px) {
      .sidebar {
        display: none;
      }
      
      .main-content {
        margin-left: 0;
      }
      
      .hero {
        padding: 20px;
      }
      
      .hero h1 {
        font-size: 2rem;
      }
      
      .book-actions {
        flex-direction: column;
      }
      
      .subcategories-grid {
        grid-template-columns: 1fr;
      }
      
      .nonfiction-subcategories {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Online Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.html">Home</a>
      
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
           <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
          <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </aside>

  <main class="main-content">
    <header class="topbar">
      <div class="search-container">
        <input id="search-input" type="text" placeholder="Search non-fiction books..." />
        <button onclick="searchSite()">Search</button>
      </div>
      <button id="theme-toggle">Dark Mode</button>
    </header>

    <section class="hero">
      <h1>Cart Summary</h1>
    </section>
    <section class="books-section">
        <div class="books-section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2 style="margin-bottom:0px">Cart Items</h2>
            <?php if (count($items) > 0): ?>
    <button class="order-btn" onClick="openOrderModal()">Order Now</button>
<?php endif; ?>
        </div>
      
      <div class="books-content">
        <?php if (count($items) > 0): ?>
            <?php foreach ($items as $item): ?>

                <div class="book-item" id="item-<?php echo $item['id']; ?>" data-genre="<?php echo strtolower($item['genre']); ?>">
                       <div class="book-header">
                        <div class="book-title-section">
                             <input 
                            type="checkbox"
                            class="select-item hidden"
                            data-book-id="<?php echo $item['book_id']; ?>"
                            data-quantity="<?php echo $item['quantity']; ?>"
                                  >
                                    <h4 class="book-title"><?php echo $item['title']; ?></h4>
                                    </div>
                                    <div class="book-actions">
                                        <button 
                            class="delete-btn" 
                            onclick="deleteItem(<?php echo $item['id']; ?>)"
                        >
                            Delete
                        </button>
            </div>
                       </div>
                    
                    <div class="book-cover">
                    <img src="<?php echo $item['cover_image']; ?>" alt="<?php echo $item['title']; ?> Book Cover">
   
                    </div>

                    <div class="book-details">
                        <p class="book-author">by <?php echo $item['publisher']; ?></p>
                     
                            <div class="star-rating">
                                <?php 
                                    $rating = intval($item['rating']); // 0–5
                                    for ($i = 1; $i <= 5; $i++) {
                                        if ($i <= $rating) {
                                            echo '<span class="star filled"></span>';
                                        } else {
                                            echo '<span class="star"></span>';
                                        }
                                    }
                                ?>
                                <p class="rating-text"><?php echo $item['rating']; ?>/5</p>
                            </div>


                        <span class="book-genre"><?php echo $item['genre']; ?></span>

                        <p class="book-description"><?php echo $item['description']; ?></p>
                        <div class="book-footer">
                            <p class="book-price">$<?php echo $item['price']; ?></p>
                             <div class="book-quantity">
        <button class="qty-btn" onclick="updateQty(this, -1)">-</button>
        <input type="number" class="qty-input" value="<?php echo $item['quantity']; ?>" min="1">
        <button class="qty-btn" onclick="updateQty(this, 1)">+</button>
    </div>

                            </div>
                        
                    </div>
                </div>

            <?php endforeach; ?>

        <?php else: ?>
            <p style="width:100%; text-align:center ;padding:20px"><b>No Cart Items found.</b></p>
        <?php endif; ?>

        </div>
     
    </section>

    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><img src="images/Facebook.jpg" alt="Facebook"></a>
        <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.jpg" alt="Instagram"></a>
        <a href="https://www.youtube.com" target="_blank"><img src="images/youtube.png" alt="YouTube"></a>
      </div>
    </footer>
    <div id="orderModal" 
     style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
            background:rgba(0,0,0,0.6); z-index:9999; justify-content:center; align-items:center;">
    
    <div style="background:white; width:400px; padding:20px; border-radius:10px; position:relative;">
        
        <h2 style="margin-bottom:15px;">Place Order</h2>

        <label><b>Shipping Address</b></label>
        <textarea id="shippingAddress" 
                  style="width:100%; height:80px; padding:8px; margin:10px 0; border:1px solid #ccc; border-radius:5px;"></textarea>

        <label><b>Payment Method</b></label>
        <input type="text" value="Cash On Delivery (COD)" disabled
               style="width:100%; padding:8px; border:1px solid #ccc; border-radius:5px; margin-bottom:20px;">

        <div style="display:flex; justify-content:space-between;">
            <button onclick="placeOrder()" 
                    style="padding:10px 20px; background:#27ae60; color:white; border:none; border-radius:5px;">
                Place Order
            </button>
            <button onclick="closeOrderModal()" 
                    style="padding:10px 20px; background:#e74c3c; color:white; border:none; border-radius:5px;">
                Cancel
            </button>
        </div>
    </div>

</div>

  </main> 

  <script>
    const userData = JSON.parse(localStorage.getItem("user"));
    // FIX: Do not default to 1. If not logged in, userId is null.
    const userId = userData ? userData.id : null; 

  // Update the href only if userId exists
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink && userId) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink && userId) {
    cartLink.href = "cart.php?userId=" + userId;
  }
  
  // LOGOUT CHECK: If no user data found, clear the cart display
  if (!userData) {
      const booksContent = document.querySelector('.books-content');
      if (booksContent) {
          booksContent.innerHTML = '<p style="width:100%; text-align:center ;padding:20px"><b>Please login to view your cart.</b></p>';
      }
      const orderBtn = document.querySelector('.order-btn');
      if (orderBtn) {
          orderBtn.style.display = 'none';
      }
  }

    // Theme Toggle
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        themeBtn.textContent = document.body.classList.contains('dark-mode') ? 'Light Mode' : 'Dark Mode';
      });

      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
        themeBtn.textContent = 'Light Mode';
      }
    }
    function showPopup(message) {
      const existingPopup = document.querySelector('.custom-popup');
      if (existingPopup) {
        existingPopup.remove();
      }
      
      const popup = document.createElement('div');
      popup.className = 'custom-popup';
      popup.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,0.9); color: white; padding: 20px 30px; border-radius: 10px; z-index: 10000; font-size: 16px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.3); min-width: 250px;';
      popup.textContent = message;
      
      document.body.appendChild(popup);
      
      setTimeout(function() {
        if (document.body.contains(popup)) {
          document.body.removeChild(popup);
        }
      }, 2000);
    }
function openOrderModal() {
    document.getElementById("orderModal").style.display = "flex";
}

function closeOrderModal() {
    document.getElementById("orderModal").style.display = "none";
}

    // Search Function for Non-Fiction Books
    function searchSite() {
      const input = document.getElementById('search-input');
      if (!input || !input.value.trim()) {
        showPopup('Please type something to search!');
        return;
      }
      
      const query = input.value.toLowerCase().trim();
      const bookItems = document.querySelectorAll('.book-item');
      
      let found = false;
      bookItems.forEach(function(book) {
        const title = book.querySelector('h4').textContent.toLowerCase();
        const author = book.querySelector('.book-author').textContent.toLowerCase();
        const description = book.querySelector('.book-description').textContent.toLowerCase();
        
        if (title.includes(query) || author.includes(query) || description.includes(query)) {
          book.style.display = 'block';
          found = true;
        } else {
          book.style.display = 'none';
        }
      });
      
      if (!found) {
        showPopup('No non-fiction books found for: ' + query);
      }
    }
    function updateQty(btn, change) {
        let input = btn.parentElement.querySelector(".qty-input");
        let value = parseInt(input.value);

        value += change;
        if (value < 1) value = 1;

        input.value = value;
    }
    let selectedItems = [];   // store selected book_id + qty

// Checkbox handler
document.addEventListener("change", function(e) {
    if (!e.target.classList.contains("select-item")) return;

    let bookId = e.target.dataset.bookId;
    let qty = e.target.dataset.quantity;

    if (e.target.checked) {
        // add to array
        selectedItems.push({ book_id: bookId, quantity: qty });
    } else {
        // remove from array
        selectedItems = selectedItems.filter(i => i.book_id !== bookId);
    }

    console.log("Selected Items:", selectedItems);
});

function placeOrder() {
    let userData = JSON.parse(localStorage.getItem("user"));
    let userId = userData ? userData.id : 1;

    let shippingAddress = document.getElementById("shippingAddress").value.trim();

    if (!shippingAddress) {
        showPopup("Please enter a shipping address!");
        return;
    }

    let items = [];

    // Loop through each book card
    document.querySelectorAll(".book-item").forEach(item => {
        let bookId = item.querySelector(".select-item").dataset.bookId;
        let qty = item.querySelector(".qty-input").value;

        items.push({
            book_id: bookId,
            quantity: qty
        });
    });

    // Prepare payload
    let payload = {
        userId: userId,
        shipping_address: shippingAddress,
        payment_type: "COD",
        status:"processing",
        items: items
    };

    fetch("place-order-api.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showPopup("Order Placed Successfully!");
            closeOrderModal();
            window.location.reload();
        } else {
            alert("Failed: " + data.message);
        }
    })
    .catch(err => console.error(err));
}




// DELETE ITEM FUNCTION
function deleteItem(cartItemId) {

    if (!confirm("Are you sure you want to remove this book from cart?")) return;

    fetch("delete-cart-items.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "id=" + cartItemId,
    })
    .then(res => res.text())
    .then(response => {
        if (response.trim() === "success") {

            // Remove from UI
            let el = document.getElementById("item-" + cartItemId);
            el.classList.add("fade-out");

            setTimeout(() => el.remove(), 300);

        } else {
            alert("Failed to remove item!");
        }
    });
}
    // Add event listener for Enter key in search
    document.getElementById('search-input').addEventListener('keyup', function(event) {
      if (event.key === 'Enter') {
        searchSite();
      }
    });

    // Initialize page
    document.addEventListener('DOMContentLoaded', function() {
      // Set initial theme
      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
        if (themeBtn) {
          themeBtn.textContent = 'Light Mode';
        }
      }
    });
  </script>
</body>
</html>