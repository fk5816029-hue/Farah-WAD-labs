<?php
include "connect.php";
header('Content-Type: application/json');

$bookId = isset($_POST['bookId']) ? intval($_POST['bookId']) : 1;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
$userId = isset($_POST['userId']) ? intval($_POST['userId']) : 1;

if ($bookId <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid book']);
    exit();
}

// ------------------------------------------
// STEP 1: Check if cart exists for user
// ------------------------------------------
$cartQuery = "SELECT id FROM carts WHERE user_id = $userId LIMIT 1";
$cartResult = mysqli_query($conn, $cartQuery);

if (mysqli_num_rows($cartResult) > 0) {
    $cart = mysqli_fetch_assoc($cartResult);
    $cartId = $cart['id'];
} else {
    // Create a new cart for this user
    $createCart = "INSERT INTO carts (user_id, quantity, added_on) 
                   VALUES ($userId, 0, NOW())";
    mysqli_query($conn, $createCart);
    $cartId = mysqli_insert_id($conn);
}

// ------------------------------------------
// STEP 2: Check if this book already exists in cart_items
// ------------------------------------------
$itemQuery = "SELECT id, quantity FROM cart_items 
              WHERE cart_id = $cartId AND book_id = $bookId LIMIT 1";
$itemResult = mysqli_query($conn, $itemQuery);

if (mysqli_num_rows($itemResult) > 0) {
    // Update quantity inside cart_items
    $item = mysqli_fetch_assoc($itemResult);
    $newQuantity = $item['quantity'] + $quantity;

    $updateItem = "UPDATE cart_items 
                   SET quantity = $newQuantity 
                   WHERE id = " . $item['id'];
    mysqli_query($conn, $updateItem);
} else {
    // Insert new item into cart_items
    $insertItem = "INSERT INTO cart_items (cart_id, book_id, quantity, created_at)
                   VALUES ($cartId, $bookId, $quantity, NOW())";
    mysqli_query($conn, $insertItem);
}

// ------------------------------------------
// STEP 3: Update cart.quantity = total items in the cart
// ------------------------------------------
$totalQuery = "SELECT SUM(quantity) AS total FROM cart_items WHERE cart_id = $cartId";
$totalResult = mysqli_query($conn, $totalQuery);
$totalRow = mysqli_fetch_assoc($totalResult);
$totalQuantity = $totalRow['total'] ?? 0;

$updateCart = "UPDATE carts SET quantity = $totalQuantity WHERE id = $cartId";
mysqli_query($conn, $updateCart);

echo json_encode(['status' => 'success', 'message' => 'Book added to cart']);
?>
