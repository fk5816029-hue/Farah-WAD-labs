<?php
include "connect.php";
$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}
// --- Get Book ID ---
if (!isset($_GET['id'])) {
    die("Book ID is missing in URL");
}
$bookId = intval($_GET['id']);

// --- Fetch book details ---
$query = "SELECT * FROM books WHERE id = $bookId LIMIT 1";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    die("Book not found");
}

$book = mysqli_fetch_assoc($result);

// --- Handle Order Submission ---
$message = "";
if (isset($_POST['order_now'])) {

    $quantity = intval($_POST['quantity']);
    $shipping_address = mysqli_real_escape_string($conn, $_POST['shipping_address']);
    
   $userId = isset($_POST['user_id']) ? intval($_POST['user_id']) : 1;
    $paymentType = "COD"; // cash on delivery

    if ($quantity < 1 || $quantity > $book['stock']) {
        $message = "Invalid quantity!";
    } else {

        $total = $quantity * $book['price'];
        $orderKey = uniqid("ORD_"); // generate unique key
        $orderDate = date("Y-m-d H:i:s");

        // Insert into orders table
        $insertOrder = "
            INSERT INTO orders (order_key, order_date, payment_type, total_amount, shipping_address, user_id)
            VALUES ('$orderKey', '$orderDate', '$paymentType', $total, '$shipping_address', $userId)
        ";

        if (mysqli_query($conn, $insertOrder)) {

            // Get the last inserted order ID
            $orderId = mysqli_insert_id($conn);

            // Insert into order_items
            $insertItem = "
                INSERT INTO order_items (order_id, book_id, quantity)
                VALUES ($orderId, $bookId, $quantity)
            ";

            mysqli_query($conn, $insertItem);

            // Reduce stock
            $newStock = $book['stock'] - $quantity;
            mysqli_query($conn, "UPDATE books SET stock = $newStock WHERE id = $bookId");

            $book['stock'] = $newStock;

            $message = "Order placed successfully! Your Order Key: <b>$orderKey</b>";
            // show_Popup($message);

        } else {
            $message = "Order Failed!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
<title>Place Order</title>

<style>

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
        display: flex;
      min-height: 100vh;
      background-color: #f5f7fa;
      color: #333;
      transition: background-color 0.3s, color 0.3s;
    }

    /* Sidebar styles */
    .sidebar {
      width: 250px;
      height: 100vh;
      background: linear-gradient(180deg, #2c3e50, #1a2530);
      color: white;
      padding: 20px;
      position: fixed;
      overflow-y: auto;
    }

    .logo {
      display: flex;
      align-items: center;
      margin-bottom: 30px;
    }

    .logo img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      margin-right: 10px;
    }

    .logo h2 {
      font-size: 1.2rem;
      font-weight: 600;
    }

    .nav-links {
      display: flex;
      flex-direction: column;
    }

    .nav-links a {
      color: #ecf0f1;
      text-decoration: none;
      padding: 12px 15px;
      margin: 5px 0;
      border-radius: 5px;
      transition: all 0.3s;
    }

    .nav-links a:hover, .nav-links a.active {
      background-color: #3498db;
      color: white;
    }

    .dropdown {
      position: relative;
       margin: 5px 0;
      padding:12px 0px;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      left: 0%;
      top: 120%;
      background-color: #34495e;
      min-width: 200px;
      border-radius: 5px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.2);
      z-index: 1;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown-content a {
      display: block;
      padding: 10px 15px;
    }

    /* Main content styles */
    .main-content {
       
      flex: 1;
      margin-left: 250px;
      padding: 20px;
    }
    .detail-body{ 
        height:100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    .topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
      padding: 15px 20px;
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .search-container {
      display: flex;
      gap: 10px;
    }

    .search-container input {
      padding: 10px 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      width: 300px;
    }

    .search-container button, #theme-toggle {
      padding: 10px 20px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .search-container button:hover, #theme-toggle:hover {
      background-color: #2980b9;
    }

    /* Hero section */
    .hero {
      background: linear-gradient(135deg, #3498db, #8e44ad);
      color: white;
      padding: 40px;
      border-radius: 10px;
      margin-bottom: 30px;
      text-align: center;
    }

    .hero h1 {
      font-size: 2.5rem;
      margin-bottom: 15px;
    }

    .hero p {
      font-size: 1.2rem;
      max-width: 700px;
      margin: 0 auto;
    }
     .footer {
      background-color: #2c3e50;
      color: white;
      padding: 30px;
      border-radius: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
     .social-icons {
      display: flex;
      gap: 15px;
    }

    .social-icons img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      transition: transform 0.3s;
    }

    .social-icons img:hover {
      transform: scale(1.1);
    }
    .container {
        max-width: 100%;
        margin-bottom: 40px;
        border: 1px solid #ddd;
        padding: 20px;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .cover_img {
        width: 100%;
        height:100%;
        border-radius: 6px;
    }
    input, textarea {
        width: 100%;
        padding: 10px;
        margin-top: 8px;
    }
    button {
        margin-top: 20px;
        padding: 12px 20px;
        background: #0d6efd;
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 6px;
    }
    button:hover {
        background: #084298;
    }
    .message {
        margin: 15px 0;
        padding: 10px;
        color: green;
    }
    .order_info {
        display: flex;
        gap: 20px;
        margin-top: 20px;
    }
    .order_image {
        flex: 1;
    }
    .order_details {
        flex:1;
    }
    .title{
        font-size: 2.5rem;
        margin-bottom: 10px;
    }
    .description,.price,.stock{
    
        font-size: 1.5rem;
        margin-bottom: 10px;

    }
    .quantity-section{
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .quantity-section label{
        margin-bottom: 0px !important;
    }
    .quantity-input{
        width: 100px;
        height: 40px;
    }
    textarea{
        font-size: 1rem;
    }
    @media (max-width :1024px) {
         .title{
        font-size: 2rem;
       
    }
    .description,.price,.stock{
    
        font-size: 1rem;
      

    }
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 143px;
        padding: 15px 10px;
      }
      
      .logo h2 {
        display: none;
      }
      
      .main-content {
        margin-left: 143px;
      }
      .order_info{
        flex-direction: column;
      }
      .topbar {
        flex-direction: column;
        gap: 15px;
      }
      
      .search-container {
        width: 100%;
      }
      
      .search-container input {
        width: 100%;
      }
      
    
      
      .footer {
        flex-direction: column;
        gap: 20px;
        text-align: center;
      }
    }

    @media (max-width: 480px) {
      .sidebar {
        display: none;
      }
      .order_info{
        flex-direction: column;
      }
      .main-content {
        margin-left: 0;
      }
      
      .hero {
        padding: 20px;
      }
      
      .hero h1 {
        font-size: 2rem;
      }
      
      
    }

</style>

</head>
<body>
 <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Online Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.php">Home</a>
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
           <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
       <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </aside>
    <!-- Main Content -->
  <main class="main-content">
    <header class="topbar">
      <div class="search-container">
        <input id="search-input" type="text" placeholder="Search fiction books..." />
        <button onclick="searchSite()">Search</button>
      </div>
      <button id="theme-toggle">Dark Mode</button>
    </header>
    <div class="detail-body">
<div class="container">

    

    <?php if ($message != "") echo "<div class='message'>$message</div>"; ?>
<div class="order_info">
<div class="order_image">
      <img src="<?php echo $book['cover_image']; ?>" class="cover_img" alt="Book Cover">
</div>
<div class="order_details">
    <h3 class="title"><?php echo $book['title']; ?></h3>
    <p class="description"><?php echo $book['description']; ?></p>
    <p class="price"><b>Price:</b> $ <?php echo $book['price']; ?></p>
    <p class="stock"><b>Available Stock:</b> <?php echo $book['stock']; ?></p>

    <form method="POST">
      <input type="hidden" name="user_id" id="user_id">

          <div class="quantity-section">
 <label class='description' ><b>Quantity</b></label>
        <input 
            type="number" 
            class="quantity-input"
            name="quantity" 
            id="qty"
            min="1" 
            max="<?php echo $book['stock']; ?>" 
            value="1"
            required
        >
          </div>
       

        <label  class='description'><b>Shipping Address</b></label>
        <textarea name="shipping_address" required placeholder="Enter full address"></textarea>

        <p><b>Total Amount:</b> $ <span id="total"><?php echo $book['price']; ?></span></p>

        <button type="submit" name="order_now">Order Now</button>
    </form>
</div>
</div>

    

</div>
    


    <!-- Footer -->
    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><img src="images/Facebook.jpg" alt="Facebook"></a>
        <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.jpg" alt="Instagram"></a>
        <a href="https://www.youtube.com" target="_blank"><img src="images/youtube.png" alt="YouTube"></a>
      </div>
    </footer>
    </div>

  </main> 


<script>
  const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

document.getElementById("user_id").value = userId;
  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
let price = <?php echo $book['price']; ?>;
let stock = <?php echo $book['stock']; ?>;
let qtyInput = document.getElementById("qty");
let totalEl = document.getElementById("total");

qtyInput.addEventListener("input", () => {
    let q = parseInt(qtyInput.value);

    if (q < 1) qtyInput.value = 1;
    if (q > stock) qtyInput.value = stock;

    totalEl.innerText = qtyInput.value * price;
});
</script>

</body>
</html>
