<?php
include "connect.php";
$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}

$category_id = isset($_GET['id']) ? intval($_GET['id']) : 1;

$subQuery = "SELECT * FROM subcategories WHERE category_id = $category_id ORDER BY id ASC";

$subQuery = "SELECT * FROM subcategories WHERE category_id = $category_id ORDER BY id ASC";
$subResult = mysqli_query($conn, $subQuery);


// Get subcategory if selected
$subcategory_id = isset($_GET['sub']) ? intval($_GET['sub']) : 0;

// Build SQL
$query = "
    SELECT books.*, subcategories.name AS genre
    FROM books
    LEFT JOIN subcategories
    ON books.subcategory_id = subcategories.id
    WHERE books.category_id = $category_id
";

if ($subcategory_id > 0) {
    $query .= " AND books.subcategory_id = $subcategory_id";
}

$result = mysqli_query($conn, $query);

$books = [];
while ($book = mysqli_fetch_assoc($result)) {
    $books[] = $book;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fiction Books - Online Book Store</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Online Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.html">Home</a>
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
           <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
        <a id="ordersLink" href="#">Orders</a>
        <a id="cartLink" href="#">Cart</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="main-content">
    <header class="topbar">
      <div class="search-container">
        <input id="search-input" type="text" placeholder="Search fiction books..." />
        <button onclick="searchSite()">Search</button>
      </div>
      <button id="theme-toggle">Dark Mode</button>
    </header>

    <!-- Hero Section -->
    <section class="hero">
      <h1>Fiction Books Collection</h1>
      <p>Discover captivating novels, thrilling mysteries, fantasy epics, and literary masterpieces from bestselling authors.</p>
    </section>

   
   <section class="fiction-subcategories">
    <h2>Explore Fiction Genres</h2>

    <div class="subcategories-grid">

        <!-- Always show ALL category -->
        <div class="subcategory-tag active" onclick="filterBooks('all')">
            All Fiction
        </div>

        <!-- Load Dynamic Subcategories -->
        <?php
        if (mysqli_num_rows($subResult) > 0) {
            while ($sub = mysqli_fetch_assoc($subResult)) { 
                $subName = $sub['name'];
                $subSlug = strtolower(str_replace(' ', '-', $subName));
        ?>
                <div class="subcategory-tag" onclick="filterBooks('<?php echo $subSlug; ?>')">
                    <?php echo $subName; ?>
                </div>
        <?php
            }
        } else {
            echo "<p>No subcategories found.</p>";
        }
        ?>

    </div>
</section>


    <!-- Fiction Books Grid -->
     <section class="books-section">
    <h2>Popular Fiction Books</h2>

    <div class="books-content">

        <?php if (count($books) > 0): ?>
            <?php foreach ($books as $book): ?>

                <div class="book-item" data-genre="<?php echo strtolower($book['genre']); ?>">

                    <h4><?php echo $book['title']; ?></h4>

                    <div class="book-cover">
                    <img src="<?php echo $book['cover_image']; ?>" alt="<?php echo $book['title']; ?> Book Cover">
   
                    <!-- <img src="uploads/<?php echo $book['image']; ?>" alt="<?php echo $book['title']; ?> Book Cover"> -->
                    </div>

                    <div class="book-details">
                        <p class="book-author">by <?php echo $book['publisher']; ?></p>

                        <!-- <div class="book-rating">
                            ⭐⭐⭐⭐⭐ <?php echo $book['rating']; ?>/5
                        </div> -->
<div class="star-rating">
    <?php 
        $rating = intval($book['rating']); // 0–5

        for ($i = 1; $i <= 5; $i++) {
            if ($i <= $rating) {
                echo '<span class="star filled"></span>';
            } else {
                echo '<span class="star"></span>';
            }
        }
    ?>
</div>


                        <span class="book-genre"><?php echo $book['genre']; ?></span>

                        <p class="book-description"><?php echo $book['description']; ?></p>

                        <p class="book-price">$<?php echo $book['price']; ?></p>

                        <div class="book-actions">
                            <button class="btn btn-primary" 
                                onclick="addToCart('<?php echo $book['id']; ?>', '<?php echo $book['title']; ?>', <?php echo $book['price']; ?>)">
                                Add to Cart
                            </button>

                        <button class="btn btn-secondary" 
                                onclick="orderNow('<?php echo $book['id']; ?>', '<?php echo $book['title']; ?>')">
                                Order Now
                            </button>
                        </div>
                    </div>
                </div>

            <?php endforeach; ?>

        <?php else: ?>
            <p>No books found in this category.</p>
        <?php endif; ?>

    </div>
</section>

    <!-- Footer -->
    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><img src="images/Facebook.jpg" alt="Facebook"></a>
        <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.jpg" alt="Instagram"></a>
        <a href="https://www.youtube.com" target="_blank"><img src="images/youtube.png" alt="YouTube"></a>
      </div>
    </footer>
  </main> 

  <script src="fiction.js"></script>
</body>
</html>