<?php
include "connect.php";
$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}

$category_id = isset($_GET['id']) ? intval($_GET['id']) : 3;

$subQuery = "SELECT * FROM subcategories WHERE category_id = $category_id ORDER BY id ASC";

$subQuery = "SELECT * FROM subcategories WHERE category_id = $category_id ORDER BY id ASC";
$subResult = mysqli_query($conn, $subQuery);


// Get subcategory if selected
$subcategory_id = isset($_GET['sub']) ? intval($_GET['sub']) : 0;

// Build SQL
$query = "
    SELECT books.*, subcategories.name AS genre
    FROM books
    LEFT JOIN subcategories
    ON books.subcategory_id = subcategories.id
    WHERE books.category_id = $category_id
";

if ($subcategory_id > 0) {
    $query .= " AND books.subcategory_id = $subcategory_id";
}

$result = mysqli_query($conn, $query);

$books = [];
while ($book = mysqli_fetch_assoc($result)) {
    $books[] = $book;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Science Books - Online Book Store</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Online Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.html">Home</a>
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
          <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
       <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="main-content">
    <header class="topbar">
      <div class="search-container">
        <input id="search-input" type="text" placeholder="Search science books..." />
        <button onclick="searchSite()">Search</button>
      </div>
      <button id="theme-toggle">Dark Mode</button>
    </header>

    <!-- Hero Section -->
    <section class="hero">
      <h1>Science Books Collection</h1>
      <p>Explore the wonders of the universe with our curated selection of science books - from quantum physics to biology and everything in between.</p>
    </section>

    <!-- Science Subcategories -->
    <section class="science-subcategories">
      <h2>Explore Science Categories</h2>
      <div class="subcategories-grid">

        <!-- Always show ALL category -->
        <div class="subcategory-tag active" onclick="filterBooks('all')">
            All Science
        </div>

        <!-- Load Dynamic Subcategories -->
        <?php
        if (mysqli_num_rows($subResult) > 0) {
            while ($sub = mysqli_fetch_assoc($subResult)) { 
                $subName = $sub['name'];
                $subSlug = strtolower(str_replace(' ', '-', $subName));
        ?>
                <div class="subcategory-tag" onclick="filterBooks('<?php echo $subSlug; ?>')">
                    <?php echo $subName; ?>
                </div>
        <?php
            }
        } else {
            echo "<p>No subcategories found.</p>";
        }
        ?>

    </div>
      <!-- <div class="subcategories-grid">
        <div class="subcategory-tag active" onclick="filterBooks('all')">All Science</div>
        <div class="subcategory-tag" onclick="filterBooks('physics')">Physics</div>
        <div class="subcategory-tag" onclick="filterBooks('biology')">Biology</div>
        <div class="subcategory-tag" onclick="filterBooks('astronomy')">Astronomy</div>
        <div class="subcategory-tag" onclick="filterBooks('chemistry')">Chemistry</div>
        <div class="subcategory-tag" onclick="filterBooks('popular')">Popular Science</div>
      </div> -->
    </section>

    <!-- Science Books Grid -->
    <section class="books-section">
      <h2>Popular Science Books</h2>
     <div class="books-content">

        <?php if (count($books) > 0): ?>
            <?php foreach ($books as $book): ?>

                <div class="book-item" data-genre="<?php echo strtolower($book['genre']); ?>">

                    <h4><?php echo $book['title']; ?></h4>

                    <div class="book-cover">
                    <img src="<?php echo $book['cover_image']; ?>" alt="<?php echo $book['title']; ?> Book Cover">
   
                    <!-- <img src="uploads/<?php echo $book['image']; ?>" alt="<?php echo $book['title']; ?> Book Cover"> -->
                    </div>

                    <div class="book-details">
                        <p class="book-author">by <?php echo $book['publisher']; ?></p>

                        <!-- <div class="book-rating">
                            ⭐⭐⭐⭐⭐ <?php echo $book['rating']; ?>/5
                        </div> -->
<div class="star-rating">
    <?php 
        $rating = intval($book['rating']); // 0–5

        for ($i = 1; $i <= 5; $i++) {
            if ($i <= $rating) {
                echo '<span class="star filled"></span>';
            } else {
                echo '<span class="star"></span>';
            }
        }
    ?>
</div>


                        <span class="book-genre"><?php echo $book['genre']; ?></span>

                        <p class="book-description"><?php echo $book['description']; ?></p>

                        <p class="book-price">$<?php echo $book['price']; ?></p>

                        <div class="book-actions">
                            <button class="btn btn-primary" 
                                onclick="addToCart('<?php echo $book['id']; ?>', '<?php echo $book['title']; ?>', <?php echo $book['price']; ?>)">
                                Add to Cart
                            </button>

                            <button class="btn btn-secondary" 
                                onclick="orderNow('<?php echo $book['id']; ?>', '<?php echo $book['title']; ?>')">
                                Order Now
                            </button>
                        </div>
                    </div>
                </div>

            <?php endforeach; ?>

        <?php else: ?>
            <p>No books found in this category.</p>
        <?php endif; ?>

    </div>
    </section>

    <!-- Science Facts Section -->
    <section class="science-facts">
      <h2>Amazing Science Facts</h2>
      <div class="facts-grid">
        <div class="fact-card">
          <div class="fact-icon">🌌</div>
          <h3>Universe Scale</h3>
          <p>There are more stars in the universe than grains of sand on all Earth's beaches</p>
        </div>
        <div class="fact-card">
          <div class="fact-icon">🧬</div>
          <h3>Human DNA</h3>
          <p>If uncoiled, the DNA in all the cells in your body would stretch 10 billion miles</p>
        </div>
        <div class="fact-card">
          <div class="fact-icon">⚛️</div>
          <h3>Atomic World</h3>
          <p>99.9999999% of an atom is empty space - we're mostly made of nothing!</p>
        </div>
        <div class="fact-card">
          <div class="fact-icon">🧠</div>
          <h3>Brain Power</h3>
          <p>Your brain generates enough electricity to power a small light bulb</p>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><img src="images/Facebook.jpg" alt="Facebook"></a>
        <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.jpg" alt="Instagram"></a>
        <a href="https://www.youtube.com" target="_blank"><img src="images/youtube.png" alt="YouTube"></a>
      </div>
    </footer>
  </main> 

  <script>
     const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }

function orderNow(bookId, title) {
    const userData = JSON.parse(localStorage.getItem("user"));
    const userId = userData ? userData.id : 1; // fallback if not logged in

   
    window.location.href = "place-order.php?id=" + bookId + "&userId=" + userId;
}

    // Theme Toggle
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        themeBtn.textContent = document.body.classList.contains('dark-mode') ? 'Light Mode' : 'Dark Mode';
      });

      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
        themeBtn.textContent = 'Light Mode';
      }
    }

    // Search Function for Science Books
    function searchSite() {
      const input = document.getElementById('search-input');
      if (!input || !input.value.trim()) {
        showPopup('Please type something to search!');
        return;
      }
      
      const query = input.value.toLowerCase().trim();
      const bookItems = document.querySelectorAll('.book-item');
      
      let found = false;
      bookItems.forEach(function(book) {
        const title = book.querySelector('h4').textContent.toLowerCase();
        const author = book.querySelector('.book-author').textContent.toLowerCase();
        const description = book.querySelector('.book-description').textContent.toLowerCase();
        
        if (title.includes(query) || author.includes(query) || description.includes(query)) {
          book.style.display = 'block';
          found = true;
        } else {
          book.style.display = 'none';
        }
      });
      
      if (!found) {
        showPopup('No science books found for: ' + query);
      }
    }
function removeSlug(genre) {
  return genre.replace(/-/g, ' ');
}
    // Filter Books by Genre
    function filterBooks(genre) {
      genre = removeSlug(genre);
      const bookItems = document.querySelectorAll('.book-item');
      const subcategoryTags = document.querySelectorAll('.subcategory-tag');
      
      // Update active tag
      subcategoryTags.forEach(function(tag) {
        tag.classList.remove('active');
        if (tag.textContent.toLowerCase().includes(genre) || (genre === 'all' && tag.textContent.includes('All Science'))) {
          tag.classList.add('active');
        }
      });
      
      if (genre === 'all') {
        bookItems.forEach(function(book) {
          book.style.display = 'block';
        });
        return;
      }
      
      bookItems.forEach(function(book) {
        const bookGenre = book.getAttribute('data-genre');
        if (bookGenre === genre) {
          book.style.display = 'block';
        } else {
          book.style.display = 'none';
        }
      });
    }

    // Cart and Wishlist functionality
    function addToCart(bookId, bookTitle, bookPrice) {
      let cart = JSON.parse(localStorage.getItem('bookCart')) || [];
      const existingItem = cart.find(function(item) {
        return item.id === bookId;
      });
      
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push({
          id: bookId,
          title: bookTitle,
          price: bookPrice,
          quantity: 1,
          dateAdded: new Date().toISOString()
        });
      }
      
      localStorage.setItem('bookCart', JSON.stringify(cart));
       let user = localStorage.getItem('user');
let userId = 1; // default if not logged in

if (user) {
    try {
        let userObj = JSON.parse(user);
        if (userObj.id) {
            userId = userObj.id;
        }
    } catch (e) {
        console.error("Error parsing user from localStorage:", e);
    }
}
      let formData = new FormData();
    formData.append('bookId', bookId);
    formData.append('quantity', 1);
    formData.append('userId', userId);

    fetch('add-to-cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        showPopup(`${bookTitle} added to cart!`);
        console.log(data);
    })
    .catch(err => {
        console.error(err);
        showPopup(`Error adding ${bookTitle} to cart.`);
    });
    }

    function addToWishlist(bookId, bookTitle) {
      let wishlist = JSON.parse(localStorage.getItem('bookWishlist')) || [];
      const existingIndex = wishlist.findIndex(function(item) {
        return item.id === bookId;
      });
      
      if (existingIndex > -1) {
        wishlist.splice(existingIndex, 1);
        showPopup(bookTitle + ' removed from wishlist');
      } else {
        wishlist.push({
          id: bookId,
          title: bookTitle,
          dateAdded: new Date().toISOString()
        });
        showPopup(bookTitle + ' added to wishlist!');
      }
      
      localStorage.setItem('bookWishlist', JSON.stringify(wishlist));
    }

    // Utility functions
    function showPopup(message) {
      const existingPopup = document.querySelector('.custom-popup');
      if (existingPopup) {
        existingPopup.remove();
      }
      
      const popup = document.createElement('div');
      popup.className = 'custom-popup';
      popup.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,0.9); color: white; padding: 20px 30px; border-radius: 10px; z-index: 10000; font-size: 16px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.3); min-width: 250px;';
      popup.textContent = message;
      
      document.body.appendChild(popup);
      
      setTimeout(function() {
        if (document.body.contains(popup)) {
          document.body.removeChild(popup);
        }
      }, 2000);
    }

    // Add event listener for Enter key in search
    document.getElementById('search-input').addEventListener('keyup', function(event) {
      if (event.key === 'Enter') {
        searchSite();
      }
    });

    // Initialize page
    document.addEventListener('DOMContentLoaded', function() {
      // Set initial theme
      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
        if (themeBtn) {
          themeBtn.textContent = 'Light Mode';
        }
      }
    });
  </script>
</body>
</html>