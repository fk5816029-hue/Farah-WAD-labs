<?php
include "connect.php";

if (!isset($_POST['id'])) {
    echo "missing_id";
    exit;
}

$id = intval($_POST['id']);

$deleteQuery = "DELETE FROM cart_items WHERE id = $id";

if (mysqli_query($conn, $deleteQuery)) {
    echo "success";
} else {
    echo "error";
}
?>
