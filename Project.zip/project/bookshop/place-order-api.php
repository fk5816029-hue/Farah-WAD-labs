<?php
include "connect.php";

header("Content-Type: application/json");

// Get JSON input
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["success" => false, "message" => "Invalid input"]);
    exit;
}

$userId = intval($data['userId']);
$shippingAddress = mysqli_real_escape_string($conn, $data['shipping_address']);
$items = $data['items'] ?? [];

if ($userId <= 0 || empty($items)) {
    echo json_encode(["success" => false, "message" => "User ID or items missing"]);
    exit;
}

// Calculate total amount
$totalAmount = 0;
$totalItemsCount = count($items);
$processedItems = [];
foreach ($items as $item) {
    $bookId = intval($item['book_id']);
    $quantity = intval($item['quantity']);

    // Get book price from books table
    $bookQuery = "SELECT price FROM books WHERE id = $bookId";
    $bookResult = mysqli_query($conn, $bookQuery);
    if (mysqli_num_rows($bookResult) == 0) continue;
    $book = mysqli_fetch_assoc($bookResult);
    $price = floatval($book['price']);

    $totalAmount += $price * $quantity;

    // Prepare items array with price for later insertion
   $processedItems[] = [
        "book_id" => $bookId,
        "quantity" => $quantity,
        "price" => $price
    ];
}
$orderKey = uniqid("ORD_"); // generate unique key
        $orderDate = date("Y-m-d H:i:s");
// Insert into orders table
$orderQuery = "
    INSERT INTO orders (order_key,order_date,user_id, total_amount, shipping_address,payment_type,status)
    VALUES ('$orderKey', '$orderDate', $userId, $totalAmount, '$shippingAddress','{$data['payment_type']}','{$data['status']}')
";

if (!mysqli_query($conn, $orderQuery)) {
    echo json_encode(["success" => false, "message" => "Failed to create order"]);
    exit;
}

$orderId = mysqli_insert_id($conn);

// Insert order items
foreach ($processedItems as $item) {
            $bookId = $item['book_id'];
            $quantity = $item['quantity'];

            $itemQuery = "
                INSERT INTO order_items (order_id, book_id, quantity)
                VALUES ($orderId, $bookId, $quantity)
            ";

            mysqli_query($conn, $itemQuery);
        // Update stock of the book
        $stockQuery = "SELECT stock FROM books WHERE id = $bookId";
        $stockResult = mysqli_query($conn, $stockQuery);

        if (mysqli_num_rows($stockResult) > 0) {
            $stockRow = mysqli_fetch_assoc($stockResult);
            $oldStock = intval($stockRow['stock']);
            $newStock = max(0, $oldStock - $quantity); // prevent negative stock

            $updateStock = "UPDATE books SET stock = $newStock WHERE id = $bookId";
            mysqli_query($conn, $updateStock);
        }

            // Remove item from cart
            $deleteCartItem = "DELETE FROM cart_items WHERE cart_id = (SELECT id FROM carts WHERE user_id = $userId LIMIT 1) AND book_id = $bookId";
            mysqli_query($conn, $deleteCartItem);
}

echo json_encode([
    "success" => true,
    "message" => "Order placed successfully",
    "orderId" => $orderId,
    "totalAmount" => $totalAmount
]);
?>
