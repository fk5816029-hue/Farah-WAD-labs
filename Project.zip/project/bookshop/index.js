
      
  const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
      // Slideshow functionality
      let slideIndex = 0;
      showSlides();

      function showSlides() {
        let slides = document.getElementsByClassName("slide");
        let dots = document.getElementsByClassName("dot");

        // Hide all slides
        for (let i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";
        }

        // Remove active class from all dots only active dot highlighted
        for (let i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }

        // Increment slide index
        slideIndex++;
        if (slideIndex > slides.length) {
          slideIndex = 1;
        }

        // Show current slide and activate corresponding dot
        if (slides[slideIndex - 1]) {
          slides[slideIndex - 1].style.display = "block";
        }
        if (dots[slideIndex - 1]) {
          dots[slideIndex - 1].className += " active";
        }

        // Change slide every 5 seconds
        setTimeout(showSlides, 5000);
      }

      // Manual slide navigation
      function currentSlide(n) {
        slideIndex = n;
        showSlides();
      }

      // Welcome Modal functionality
      document.addEventListener("DOMContentLoaded", function () {
        const modal = document.getElementById("welcomeModal");
        const closeBtn = document.querySelector(".close-btn");
        const exploreBtn = document.getElementById("exploreBtn");

        // Show modal on page load (after 1 second delay)
        setTimeout(function () {
          if (modal) {
            modal.style.display = "flex";
          }
        }, 1000);

        // Close modal when close button is clicked
        if (closeBtn) {
          closeBtn.addEventListener("click", function () {
            if (modal) {
              modal.style.display = "none";
            }
          });
        }

        // Close modal and scroll to content when explore button is clicked
        if (exploreBtn) {
          exploreBtn.addEventListener("click", function () {
            if (modal) {
              modal.style.display = "none";
            }
            const heroSection = document.querySelector(".hero");
            if (heroSection) {
              heroSection.scrollIntoView({ behavior: "smooth" });
            }
          });
        }

        // Close modal when clicking outside the modal content
        window.addEventListener("click", function (event) {
          if (event.target === modal) {
            modal.style.display = "none";
          }
        });
      });

      // Toggle read more functionality for articles
      function toggleReadMore(button) {
        const articleContent = button.parentElement;
        const excerpt = articleContent.querySelector(".article-excerpt");
        const fullText = articleContent.querySelector(".article-full");

        if (fullText.style.display === "none") {
          excerpt.style.display = "none";
          fullText.style.display = "block";
          button.textContent = "Read Less ←";
        } else {
          excerpt.style.display = "block";
          fullText.style.display = "none";
          button.textContent = "Read More →";
        }
      }

      // Search functionality
      function searchSite() {
        const searchInput = document.getElementById("search-input");
        if (!searchInput) return;

        const searchTerm = searchInput.value.toLowerCase().trim();

        if (!searchTerm) {
          showPopup("Please enter a search term");
          return;
        }

        // Simple search implementation
        const searchableElements = document.querySelectorAll(
          "h1, h2, h3, h4, h5, h6, p, span, a, li"
        );
        let found = false;

        // Remove previous highlights
        removeHighlights();

        searchableElements.forEach((element) => {
          const text = element.textContent.toLowerCase();
          if (text.includes(searchTerm)) {
            highlightText(element, searchTerm);
            found = true;

            // Scroll to first occurrence
            if (!window.searched) {
              element.scrollIntoView({ behavior: "smooth", block: "center" });
              window.searched = true;
            }
          }
        });

        if (!found) {
          showPopup("No results found for: " + searchTerm);
        }
      }

      function highlightText(element, searchTerm) {
        const regex = new RegExp(searchTerm, "gi");
        element.innerHTML = element.innerHTML.replace(
          regex,
          '<mark style="background-color: yellow; color: black;">$&</mark>'
        );
      }


      function removeHighlights() {
        const marks = document.querySelectorAll("mark");
        marks.forEach((mark) => {
          const parent = mark.parentNode;
          parent.replaceChild(document.createTextNode(mark.textContent), mark);
          parent.normalize();
        });
        window.searched = false;
      }

      function showPopup(message) {
        // Remove existing popup if any
        const existingPopup = document.querySelector(".custom-popup");
        if (existingPopup) {
          existingPopup.remove();
        }

        const popup = document.createElement("div");
        popup.className = "custom-popup";
        popup.textContent = message;
        popup.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0,0,0,0.9);
        color: white;
        padding: 20px 30px;
        border-radius: 10px;
        z-index: 10000;
        font-size: 16px;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        min-width: 250px;
    `;

        document.body.appendChild(popup);

        setTimeout(function () {
          if (document.body.contains(popup)) {
            document.body.removeChild(popup);
          }
        }, 2000);
      }

      // Theme toggle functionality
      document.addEventListener("DOMContentLoaded", function () {
        const themeToggle = document.getElementById("theme-toggle");

        if (themeToggle) {
          // Check for saved theme preference
          const savedTheme =
            localStorage.getItem("theme") ||
            (window.matchMedia("(prefers-color-scheme: dark)").matches
              ? "dark"
              : "light");

          // Apply the saved theme
          if (savedTheme === "dark") {
            document.body.classList.add("dark-mode");
            themeToggle.textContent = "Light Mode";
          }

          // Toggle theme when button is clicked
          themeToggle.addEventListener("click", function () {
            document.body.classList.toggle("dark-mode");

            if (document.body.classList.contains("dark-mode")) {
              localStorage.setItem("theme", "dark");
              themeToggle.textContent = "Light Mode";
            } else {
              localStorage.setItem("theme", "light");
              themeToggle.textContent = "Dark Mode";
            }
          });
        }
      });

      // Add keyboard support for search
      document.addEventListener("DOMContentLoaded", function () {
        const searchInput = document.getElementById("search-input");

        if (searchInput) {
          searchInput.addEventListener("keyup", function (event) {
            if (event.key === "Enter") {
              searchSite();
            }
          });
        }
      });

      // Smooth scrolling for internal links
      document.addEventListener("DOMContentLoaded", function () {
        const internalLinks = document.querySelectorAll('a[href^="#"]');

        internalLinks.forEach((link) => {
          link.addEventListener("click", function (e) {
            e.preventDefault();

            const targetId = this.getAttribute("href");
            if (targetId === "#") return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
              targetElement.scrollIntoView({
                behavior: "smooth",
                block: "start",
              });
            }
          });
        });
      });

      // Initialize articles with proper display
      document.addEventListener("DOMContentLoaded", function () {
        // Ensure all article excerpts are visible and full text hidden initially
        const articleExcerpts = document.querySelectorAll(".article-excerpt");
        const articleFullTexts = document.querySelectorAll(".article-full");

        articleExcerpts.forEach((excerpt) => {
          excerpt.style.display = "block";
        });

        articleFullTexts.forEach((fullText) => {
          fullText.style.display = "none";
        });
      });

      // Add loading state for images
      document.addEventListener("DOMContentLoaded", function () {
        const images = document.querySelectorAll("img");

        images.forEach((img) => {
          // Add loading state
          if (!img.complete) {
            img.style.opacity = "0.7";
            img.addEventListener("load", function () {
              this.style.opacity = "1";
            });
          }
        });
      });

// ====================== HEADER UPDATE LOGIC ======================
function updateHeader() {
  const headerRight = document.getElementById("header-right");
  if(!headerRight) return;

  // 1. TRY TO GET USER FROM LOCALSTORAGE (Commonly used in your project)
  let currentUser = JSON.parse(localStorage.getItem("user"));
  
  // 2. IF NOT FOUND, TRY SESSIONSTORAGE (As backup)
  if (!currentUser) {
      currentUser = JSON.parse(sessionStorage.getItem("lms_current_user"));
  }

  if(currentUser) {
    // === IF LOGGED IN: SHOW PROFILE & LOGOUT ===
    headerRight.innerHTML = `
      <div class="profile-wrapper">
        <div class="profile-icon">${currentUser.name ? currentUser.name[0].toUpperCase() : 'U'}</div>
        <div class="profile-dropdown">
          <p><strong>${currentUser.name || 'User'}</strong></p>
          <p>${currentUser.email || ''}</p>
          <button id="logout-btn">Logout</button>
        </div>
      </div>
    `;

    // Logout functionality
    const logoutBtn = document.getElementById("logout-btn");
    if(logoutBtn) {
        logoutBtn.addEventListener("click", () => {
        sessionStorage.removeItem("lms_current_user");
        localStorage.removeItem("user");
        // Reloads the current page (index.php) to update the header back to "Login/Register"
        window.location.reload(); 
        });
    }

    // Dropdown toggle logic
    const profileIcon = document.querySelector(".profile-icon");
    const dropdown = document.querySelector(".profile-dropdown");

    if(profileIcon && dropdown) {
        profileIcon.addEventListener("click", (e) => {
            e.stopPropagation();
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
        });

        // hide dropdown if clicked outside
        document.addEventListener("click", e => {
            const wrapper = document.querySelector(".profile-wrapper");
            if(wrapper && !wrapper.contains(e.target)) {
                dropdown.style.display = "none";
            }
        });
    }

  } else {
    // === IF NOT LOGGED IN: SHOW REGISTER & LOGIN BUTTONS ===
    headerRight.innerHTML = `
    <a href="register.php" class="login-btn" style="background-color: green; color: white;">Register</a>
      <a href="login.php" class="login-btn" style="background-color: green; color: white;">Login</a>
    `;
  }
}

// Run updateHeader when page loads
window.addEventListener("load", updateHeader);

// ALSO update the separate authArea if it exists (for compatibility)
document.addEventListener("DOMContentLoaded", function () {
    const authArea = document.getElementById("authArea");
    // Check localstorage
    const user = JSON.parse(localStorage.getItem("user"));
    
    if (authArea) {
        if (user) {
            authArea.innerHTML = ``; // Clear it so we don't have duplicates, or leave empty
        } else {
             // Leave empty to avoid duplicate buttons since we are using header-right now
            authArea.innerHTML = ``;
        }
    }
});
  