<?php
include "connect.php";
$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Us - Online Book Store</title>
    <link rel="stylesheet" href="style.css" />
</head>
<link rel="stylesheet" href="about.css" />
<body>
  <!--SideBar-->
  <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.html">Home</a>
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
          <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
        <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
      <a href="about.php" class="active">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </aside>

  <!--Main Section-->
  <main class="main-content">
    <header class="topbar">
      
      
      <button id="theme-toggle">Dark Mode</button>
      
      <!-- Profile Option in Topbar -->
      
    </header>

    <!-- About Hero Section -->
    <section class="about-hero">
      <h1>About Us</h1>
      <p class="hero-subtitle">Dedicated to spreading the light of knowledge, providing quality books to every reader</p>
    </section>

    <!-- About Content -->
    <div class="about-content">
      <div class="about-main">
        <p>Online Book Store is Pakistan's largest online library providing quality books to readers since 2015. Our mission is to make knowledge accessible to every individual.</p>
        
        <div class="stats-container">
          <div class="stat-card">
            <h3>50,000+</h3>
            <p>Regular Readers</p>
          </div>
          <div class="stat-card">
            <h3>25,000+</h3>
            <p>Books Available</p>
          </div>
          <div class="stat-card">
            <h3>100+</h3>
            <p>Authors</p>
          </div>
          <div class="stat-card">
            <h3>98%</h3>
            <p>Satisfied Customers</p>
          </div>
        </div>
      </div>

       <!-- Team Section -->
<div class="team-section">
    <h2>Our Team</h2>
    <div class="team-grid">
        <!-- Alisha - First Card -->
        <div class="team-member" onclick="openTeamProfile('alisha')">
            <div class="member-photo">
                <img src="images/alishateam.jpg" alt="Alisha - Founder & CEO" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="photo-fallback">A</div>
            </div>
            <h4>Alisha</h4>
            <div class="position">Team Leader</div>
         <p>
I am Alisha,Leading the team with vision and dedication, I ensure every project is executed with excellence.
</p>

            <div class="view-profile">View Profile →</div>
        </div>

        <!-- Khansa - Second Card -->
        <div class="team-member" onclick="openTeamProfile('khansa')">
            <div class="member-photo">
                <img src="images/team/khansa.jpg" alt="Khansa - Chief Operations Officer" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="photo-fallback">K</div>
            </div>
            <h4>Khansa</h4>
            <div class="position">Chief Operations Officer</div>
            <p>Expert in operations and customer service with 8+ years in the publishing industry</p>
            <div class="view-profile">View Profile →</div>
        </div>

        <!-- Abeeha - Third Card -->
        <div class="team-member" onclick="openTeamProfile('abeeha')">
            <div class="member-photo">
                <img src="images/team/abeeha.jpg" alt="Abeeha - Head of Content" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="photo-fallback">A</div>
            </div>
            <h4>Abeeha</h4>
            <div class="position">Head of Content</div>
            <p>Masters in Library Science, expert in book selection and cataloging</p>
            <div class="view-profile">View Profile →</div>
        </div>

        <!-- Farah - Fourth Card -->
        <div class="team-member" onclick="openTeamProfile('farah')">
            <div class="member-photo">
                <img src="images/farahpic.jpg" alt="Farah - Technical Director" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="photo-fallback">F</div>
            </div>
            <h4>Farah</h4>
            <div class="position">Technical Director</div>
            <p>Expert in web development and database management, working to improve the platform</p>
            <div class="view-profile">View Profile →</div>
        </div>
    </div>
</div>

        <!-- Professional Cards Section -->
      <div class="about-cards">
        <div class="professional-card">
          <div class="card-icon">📚</div>
          <h3>Our Mission</h3>
          <p>Our mission is to make quality books accessible to every individual. Whether they are students, researchers, or general readers, we provide equal opportunities for all.</p>
        </div>

        <div class="professional-card">
          <div class="card-icon">🎯</div>
          <h3>Our Vision</h3>
          <p>We envision a society where every individual is passionate about reading and enlightened with knowledge. We strive to bring books to every household.</p>
        </div>

        <div class="professional-card">
          <div class="card-icon">💫</div>
          <h3>Our Services</h3>
          <p>We provide thousands of books in both Urdu and English languages. Complete collection on topics like fiction, non-fiction, science, history, religion, and self-development.</p>
        </div>
      </div>

      <!-- Values Section -->
      <div class="values-section">
        <h2>Our Values</h2>
        <div class="values-grid">
          <div class="value-item">
            <h4>Quality</h4>
            <p>We provide only quality and authentic books. Every book is carefully reviewed before being added to our library.</p>
          </div>
          <div class="value-item">
            <h4>Convenience</h4>
            <p>Easy search, fast delivery, and simple payment methods. We provide every possible facility for our readers.</p>
          </div>
          <div class="value-item">
            <h4>Transparency</h4>
            <p>All our dealings are completely transparent. Book prices, delivery charges - everything is clearly stated.</p>
          </div>
        </div>
      </div>
    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank">
          <img src="images/Facebook.jpg" alt="Facebook">
        </a>
        <a href="https://www.instagram.com" target="_blank">
          <img src="images/instagram.jpg" alt="Instagram">
        </a>
        <a href="https://www.youtube.com" target="_blank">
          <img src="images/youtube.png" alt="YouTube">
        </a>
      </div>
    </footer>
  </main>
  
  <script src="about.js"></script>  
</body>
</html>