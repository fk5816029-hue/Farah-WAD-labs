<?php
include "connect.php";
$subCategoryQuery = "SELECT * FROM categories  ORDER BY id ASC";

$subCategoryResult = mysqli_query($conn, $subCategoryQuery);
$categoriesList = [];

if (mysqli_num_rows($subCategoryResult) > 0) {
    while ($row = mysqli_fetch_assoc($subCategoryResult)) {
        $categoryId = $row['id'];

        // Get book count for this category
        $countQuery = "SELECT COUNT(*) as book_count FROM books WHERE category_id = $categoryId";
        $countResult = mysqli_query($conn, $countQuery);
        $countRow = mysqli_fetch_assoc($countResult);
        $row['book_count'] = $countRow['book_count'];

        $categoriesList[] = $row;
    }
}
$userId = 1; // replace with logged-in user id in real scenario
if (isset($_GET['userId'])) {
    $userId = intval($_GET['userId']);
}
$ordersQuery = "
    SELECT o.id, o.order_key, o.order_date, o.payment_type, o.total_amount, o.shipping_address, COUNT(oi.id) as items_count
    FROM orders o
    LEFT JOIN order_items oi ON o.id = oi.order_id
    WHERE o.user_id = $userId
    GROUP BY o.id
    ORDER BY o.order_date DESC
";
$ordersResult = mysqli_query($conn, $ordersQuery);
$ordersList = [];
if(mysqli_num_rows($ordersResult) > 0){
    while($row = mysqli_fetch_assoc($ordersResult)){
        $ordersList[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
<title>Order Book</title>

<style>

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
        display: flex;
      min-height: 100vh;
      background-color: #f5f7fa;
      color: #333;
      transition: background-color 0.3s, color 0.3s;
    }

    /* Sidebar styles */
    .sidebar {
      width: 250px;
      height: 100vh;
      background: linear-gradient(180deg, #2c3e50, #1a2530);
      color: white;
      padding: 20px;
      position: fixed;
      overflow-y: auto;
    }

    .logo {
      display: flex;
      align-items: center;
      margin-bottom: 30px;
    }

    .logo img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      margin-right: 10px;
    }

    .logo h2 {
      font-size: 1.2rem;
      font-weight: 600;
    }

    .nav-links {
      display: flex;
      flex-direction: column;
    }

    .nav-links a {
      color: #ecf0f1;
      text-decoration: none;
      padding: 12px 15px;
      margin: 5px 0;
      border-radius: 5px;
      transition: all 0.3s;
    }

    .nav-links a:hover, .nav-links a.active {
      background-color: #3498db;
      color: white;
    }

    .dropdown {
      position: relative;
      margin: 5px 0;
      padding:12px 0px;
      
    }

    .dropdown-content {
      display: none;
      position: absolute;
      left: 0%;
      top: 120%;
      background-color: #34495e;
      min-width: 200px;
      border-radius: 5px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.2);
      z-index: 1;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .dropdown-content a {
      display: block;
      padding: 10px 15px;
    }

    /* Main content styles */
    .main-content {
       
      flex: 1;
      margin-left: 250px;
      padding: 20px;
    }
    .detail-body{ 
        height:100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    .topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
      padding: 15px 20px;
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .search-container {
      display: flex;
      gap: 10px;
    }

    .search-container input {
      padding: 10px 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      width: 300px;
    }

    .search-container button, #theme-toggle {
      padding: 10px 20px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .search-container button:hover, #theme-toggle:hover {
      background-color: #2980b9;
    }

   
     .footer {
      background-color: #2c3e50;
      color: white;
      padding: 30px;
      border-radius: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
     .social-icons {
      display: flex;
      gap: 15px;
    }

    .social-icons img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      transition: transform 0.3s;
    }

    .social-icons img:hover {
      transform: scale(1.1);
    }
    .container {
        max-width: 100%;
        margin-bottom: 40px;
        border: 1px solid #ddd;
        padding: 20px;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .cover_img {
        width: 100%;
        height:100%;
        border-radius: 6px;
    }
    input, textarea {
        width: 100%;
        padding: 10px;
        margin-top: 8px;
    }
    button {
        margin-top: 20px;
        padding: 12px 20px;
        background: #0d6efd;
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 6px;
    }
    button:hover {
        background: #084298;
    }
    @media (max-width :1024px) {
         .title{
        font-size: 2rem;
       
    }
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 143px;
        padding: 15px 10px;
      }
      
      .logo h2 {
        display: none;
      }
      
      .main-content {
        margin-left: 143px;
      }
      .topbar {
        flex-direction: column;
        gap: 15px;
      }
      
      .search-container {
        width: 100%;
      }
      
      .search-container input {
        width: 100%;
      }
      .footer {
        flex-direction: column;
        gap: 20px;
        text-align: center;
      }
    }

    @media (max-width: 480px) {
      .sidebar {
        display: none;
      }
      .order_info{
        flex-direction: column;
      }
      .main-content {
        margin-left: 0;
      }
    }

</style>

</head>
<body>
 <aside class="sidebar">
    <div class="logo">
      <img src="images/logo2.jpg" alt="Online Book Store Logo" />
      <h2>BOOKSTORE</h2>
    </div>

    <nav class="nav-links">
      <a href="index.html">Home</a>
      <div class="dropdown">
        <a href="categories.php" class="dropbtn">Categories ▼</a>
        <div class="dropdown-content">
           <?php
foreach ($categoriesList as $sub) {
    $subName = $sub['name'];
    $subSlug = strtolower(str_replace(' ', '-', $subName));
?>
<a href="<?php echo $subSlug; ?>.php" ><?php echo $subName; ?></a>
<?php } ?>
        </div>
      </div>
       <a id="ordersLink" href="#">Orders</a>
          <a id="cartLink" href="#">Cart</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
    </nav>
  </aside>
    <!-- Main Content -->
  <main class="main-content">
    <header class="topbar">
      <div class="search-container">
        <input id="search-input" type="text" placeholder="Search fiction books..." />
        <button onclick="searchSite()">Search</button>
      </div>
      <button id="theme-toggle">Dark Mode</button>
    </header>
    <div class="detail-body">
     
      <div class="container">
         <h1>All Orders</h1>
        <?php if(count($ordersList) > 0): ?>
<table style="width:100%; border-collapse: collapse; margin-top: 20px;">
    <thead>
        <tr style="background-color:#3498db; color:white;">
            <th style="padding: 10px; border:1px solid #ddd;">Order Key</th>
            <th style="padding: 10px; border:1px solid #ddd;">Order Date</th>
            <th style="padding: 10px; border:1px solid #ddd;">Payment Type</th>
            <th style="padding: 10px; border:1px solid #ddd;">Total Amount</th>
            <th style="padding: 10px; border:1px solid #ddd;">Items</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($ordersList as $order): ?>
        <tr onclick="window.location='order-details.php?orderId=<?php echo $order['id']; ?>'" style="cursor:pointer;">
            <td style="padding: 10px; border:1px solid #ddd;"><?php echo $order['order_key']; ?></td>
            <td style="padding: 10px; border:1px solid #ddd;"><?php echo date("d M Y, H:i", strtotime($order['order_date'])); ?></td>
            <td style="padding: 10px; border:1px solid #ddd;"><?php echo $order['payment_type']; ?></td>
            <td style="padding: 10px; border:1px solid #ddd;">$ <?php echo $order['total_amount']; ?></td>
            <td style="padding: 10px; border:1px solid #ddd;"><?php echo $order['items_count']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
<p>No orders found.</p>
<?php endif; ?>
      </div>
    


    <!-- Footer -->
    <footer class="footer">
      <p>© 2025 Online Book Store. All rights reserved.</p>
      <div class="social-icons">
        <a href="https://www.facebook.com" target="_blank"><img src="images/Facebook.jpg" alt="Facebook"></a>
        <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.jpg" alt="Instagram"></a>
        <a href="https://www.youtube.com" target="_blank"><img src="images/youtube.png" alt="YouTube"></a>
      </div>
    </footer>
    </div>

  </main> 


<script>
  const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
let price = <?php echo $book['price']; ?>;
let stock = <?php echo $book['stock']; ?>;
let qtyInput = document.getElementById("qty");
let totalEl = document.getElementById("total");

qtyInput.addEventListener("input", () => {
    let q = parseInt(qtyInput.value);

    if (q < 1) qtyInput.value = 1;
    if (q > stock) qtyInput.value = stock;

    totalEl.innerText = qtyInput.value * price;
});
</script>

</body>
</html>
