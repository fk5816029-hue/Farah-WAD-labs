
      const userData = JSON.parse(localStorage.getItem("user"));
  const userId = userData ? userData.id : 1; // default to 1 if missing

  // Update the href
  const ordersLink = document.getElementById("ordersLink");
   const cartLink = document.getElementById("cartLink");
  if (ordersLink) {
    ordersLink.href = "orders.php?userId=" + userId;
  }
  if (cartLink) {
    cartLink.href = "cart.php?userId=" + userId;
  }
    // Theme Toggle
    document.addEventListener('DOMContentLoaded', function() {
        const themeToggle = document.getElementById('theme-toggle');
        
        if (themeToggle) {
            // Check for saved theme preference
            const savedTheme = localStorage.getItem('theme') || 
                (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            
            // Apply the saved theme
            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
                themeToggle.textContent = 'Light Mode';
            }
            
            // Toggle theme when button is clicked
            themeToggle.addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                
                if (document.body.classList.contains('dark-mode')) {
                    localStorage.setItem('theme', 'dark');
                    themeToggle.textContent = 'Light Mode';
                } else {
                    localStorage.setItem('theme', 'light');
                    themeToggle.textContent = 'Dark Mode';
                }
            });
        }
    });

    // Search Functionality
    function searchSite() {
        const searchInput = document.getElementById('search-input');
        if (!searchInput) return;
        
        const searchTerm = searchInput.value.trim();
        
        if (!searchTerm) {
            showPopup('Please type something to search');
            return;
        }
        
        // Simple search implementation for about page
        const searchableContent = [
            'mission', 'vision', 'services', 'books', 'readers', 
            'authors', 'quality', 'convenience', 'transparency', 'team'
        ];
        
        const found = searchableContent.some(term => 
            term.includes(searchTerm.toLowerCase()) || searchTerm.toLowerCase().includes(term)
        );
        
        if (found) {
            highlightSearchTerms(searchTerm);
            showPopup('Search results found');
        } else {
            showPopup('No search results found for: ' + searchTerm);
        }
    }

    function highlightSearchTerms(term) {
        const elements = document.querySelectorAll('h1, h2, h3, h4, p');
        elements.forEach(element => {
            const html = element.innerHTML;
            const regex = new RegExp(`(${term})`, 'gi');
            const newHtml = html.replace(regex, '<mark style="background-color: yellow; color: black;">$1</mark>');
            element.innerHTML = newHtml;
        });
    }

    function showPopup(message) {
        // Remove existing popup if any
        const existingPopup = document.querySelector('.custom-popup');
        if (existingPopup) {
            existingPopup.remove();
        }
        
        const popup = document.createElement('div');
        popup.className = 'custom-popup';
        popup.textContent = message;
        popup.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0,0,0,0.9);
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            z-index: 10000;
            font-size: 16px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            min-width: 250px;
        `;
        
        document.body.appendChild(popup);
        
        setTimeout(function() {
            if (document.body.contains(popup)) {
                document.body.removeChild(popup);
            }
        }, 2000);
    }

    // Stats Counter Animation
    document.addEventListener('DOMContentLoaded', function() {
        const statCards = document.querySelectorAll('.stat-card h3');
        
        const animateStats = () => {
            statCards.forEach(stat => {
                const target = parseInt(stat.textContent.replace('+', ''));
                let current = 0;
                const increment = target / 50;
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        stat.textContent = target + (stat.textContent.includes('+') ? '+' : '');
                        clearInterval(timer);
                    } else {
                        stat.textContent = Math.floor(current) + (stat.textContent.includes('+') ? '+' : '');
                    }
                }, 30);
            });
        };

        // Animate stats when page loads
        setTimeout(animateStats, 1000);
    });
// Team member profile navigation
function openTeamProfile(memberName) {
    const profilePages = {
        'alisha': 'alisha/index.html',
        'khansa': 'k/index.html', 
        'abeeha': 'abeeha-profile.html',
        'farah': 'Farahpro/index.html'
    };
    
    const profilePage = profilePages[memberName];
    if (profilePage) {
        window.location.href = profilePage;
    }
}

// Preload team images for better performance
function preloadTeamImages() {
    const teamImages = [
        'images/alishateam.jpg',
        'images/khansa.jpg',
        'images/team/abeeha.jpg',
        'images/farahpic.jpg'
    ];
    
    teamImages.forEach(src => {
        const img = new Image();
        img.src = src;
    });
}

// Add enhanced interactivity
document.addEventListener('DOMContentLoaded', function() {
    // Preload images
    preloadTeamImages();
    
    const teamMembers = document.querySelectorAll('.team-member');
    
    teamMembers.forEach(member => {
        // Add ARIA labels for accessibility
        const memberName = member.querySelector('h4').textContent;
        const memberPosition = member.querySelector('.position').textContent;
        member.setAttribute('aria-label', `View ${memberName}'s profile - ${memberPosition}`);
        
        // Add tabindex for keyboard navigation
        member.setAttribute('tabindex', '0');
        
        // Enter key support
        member.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const onClick = this.getAttribute('onclick');
                if (onClick) {
                    const memberName = onClick.match(/'([^']+)'/)[1];
                    openTeamProfile(memberName);
                }
            }
        });
        
        // Enhanced click feedback
        member.addEventListener('click', function(e) {
            // Add ripple effect
            const ripple = document.createElement('div');
            ripple.style.cssText = `
                position: absolute;
                border-radius: 50%;
                background: rgba(52, 152, 219, 0.3);
                transform: scale(0);
                animation: ripple 0.6s linear;
                pointer-events: none;
            `;
            
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
});

// Add ripple animation to CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
    // Add keyboard support for search
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('search-input');
        
        if (searchInput) {
            searchInput.addEventListener('keyup', function(event) {
                if (event.key === 'Enter') {
                    searchSite();
                }
            });
        }
    });

    // Smooth scrolling for internal links
    document.addEventListener('DOMContentLoaded', function() {
        const internalLinks = document.querySelectorAll('a[href^="#"]');
        
        internalLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    });
 