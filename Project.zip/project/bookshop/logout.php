<?php
session_start();
include 'connect.php';

// 1. Update Database (Save Logout Time)
if (isset($_SESSION['current_log_id'])) {
    $log_id = $_SESSION['current_log_id'];
    $sql = "UPDATE login_history SET logout_time = NOW() WHERE id = '$log_id'";
    mysqli_query($conn, $sql);
}

// 2. Destroy Server Session
session_unset();
session_destroy();

// 3. Clear Browser Memory and Redirect
echo "
<script>
   
    
    Redirect to login page
    window.location.href = 'login.php';
</script>
";
exit;
?>