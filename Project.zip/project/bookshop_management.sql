-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2025 at 02:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookshop_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_id` int(99) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `cover_image` text DEFAULT NULL,
  `rating` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `description`, `price`, `stock`, `publisher`, `category_id`, `subcategory_id`, `cover_image`, `rating`) VALUES
(1, 'The Silent Witness', 'A gripping thriller about a lone witness who uncovers a deadly conspiracy in her small town.', 14.99, 26, 'HarperCollins', 1, 1, 'https://images.unsplash.com/photo-1528207776546-365bb710ee93', 5),
(2, 'Dark Alley Secrets', 'A detective must solve a series of mysterious murders happening in the darkest corners of the city.', 12.50, 20, 'Penguin Books', 1, 1, 'https://images.unsplash.com/photo-1507842217343-583bb7270b66', 3),
(3, 'The Final Clue', 'A suspenseful tale where every clue leads deeper into a web of lies and betrayal.', 16.00, 30, 'Random House', 1, 1, 'https://images.unsplash.com/photo-1514890547357-a9ee28872806', 1),
(4, 'Love Across Oceans', 'An emotional love story between two souls separated by distance but united by fate.', 13.99, 35, 'Bloomsbury', 1, 2, 'https://images.unsplash.com/photo-1517841905240-472988babdf9', 5),
(5, 'Whispers of the Heart', 'A heartfelt romance about rediscovering love after heartbreak.', 11.99, 48, 'Pan Macmillan', 1, 2, 'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d', 2),
(6, 'Forever & Always', 'A charming romantic tale of two people who are destined to be together.', 15.49, 45, 'Scholastic', 1, 2, 'https://images.unsplash.com/photo-1504198453319-5ce911bafcde', 1),
(7, 'Realm of Shadows', 'A magical adventure into a world filled with mythical creatures and ancient powers.', 17.99, 40, 'Orbit Books', 1, 3, 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee', 4),
(8, 'Dragonspire', 'A young hero must rise to tame dragons and protect his kingdom.', 19.50, 7, 'Tor Books', 1, 3, 'https://images.unsplash.com/photo-1519681393784-d120267933ba', 5),
(9, 'Wings of Eternity', 'A fantasy saga about a winged civilization fighting for survival.', 18.99, 28, 'HarperVoyager', 1, 3, 'https://images.unsplash.com/photo-1516979187457-637abb4f9353', 2),
(10, 'Galactic Horizon', 'A futuristic journey across galaxies where humanity faces its greatest challenge.', 20.00, 30, 'Del Rey', 1, 4, 'https://images.unsplash.com/photo-1454789548928-9efd52dc4031', 3),
(11, 'Neon Future', 'Cyberpunk sci-fi about a hacker discovering the truth behind a powerful AI.', 18.49, 22, 'Orbit Books', 1, 4, 'https://images.unsplash.com/photo-1498050108023-c5249f4df085', 1),
(12, 'Starfall Legacy', 'A space opera following a rebel crew fighting against a galactic empire.', 21.99, 15, 'Penguin Random House', 1, 4, 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa', 4),
(13, 'Echoes of Time', 'A timeless tale exploring human emotions and the meaning of life.', 10.99, 60, 'Oxford Classics', 1, 5, 'https://images.unsplash.com/photo-1528207776546-365bb710ee93', 1),
(14, 'Winds of the Past', 'A classic novel reflecting on love, loss, and redemption.', 12.00, 40, 'Vintage Books', 1, 5, 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570', 5),
(15, 'The Forgotten Pages', 'A literary masterpiece uncovering the hidden stories of an old world.', 11.50, 55, 'Penguin Classics', 1, 5, 'https://images.unsplash.com/photo-1516979187457-637abb4f9353', 5),
(16, 'Life of a Visionary', 'An inspiring biography detailing the journey of a remarkable individual who changed the world.', 18.99, 33, 'HarperCollins', 2, 6, 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70', 5),
(17, 'Footsteps of Greatness', 'A moving look into the challenges and triumphs of a legendary historical figure.', 16.50, 36, 'Penguin Books', 2, 6, 'https://images.unsplash.com/photo-1516979187457-637abb4f9353', 1),
(18, 'Unwritten Stories', 'A compelling biography uncovering the untold stories that shaped a leader’s life.', 19.99, 25, 'Random House', 2, 6, 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d', 5),
(19, 'Echoes of Civilization', 'A deep exploration into ancient civilizations and their influence on modern society.', 14.99, 49, 'Oxford Press', 2, 7, 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e', 1),
(20, 'Warriors of the Past', 'A detailed account of major historical battles that shaped nations.', 17.49, 30, 'Cambridge Publishing', 2, 7, 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05', 1),
(21, 'A Journey Through Time', 'A fascinating look at world events that changed humanity forever.', 15.99, 45, 'Vintage Books', 2, 7, 'https://images.unsplash.com/photo-1531243269051-74dfe2f1f1c5', 5),
(22, 'The Power Within', 'A practical guide to unlocking your inner strength and achieving personal growth.', 12.99, 60, 'Bloom Books', 2, 8, 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b', 1),
(23, 'Mindset Shift', 'A life-changing guide about transforming your mindset and embracing positivity.', 14.50, 55, 'Pan Macmillan', 2, 8, 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1', 4),
(24, 'Rise & Improve', 'A motivational book focusing on habits that lead to long-term success.', 13.99, 70, 'Scholastic', 2, 8, 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e', 3),
(25, 'The Strategy Blueprint', 'A powerful guidebook for entrepreneurs aiming to build scalable businesses.', 19.99, 30, 'Harvard Business Press', 2, 9, 'https://images.unsplash.com/photo-1554774853-b414d2a3d1fb', 2),
(26, 'Money & Mindset', 'A practical look at financial intelligence and mastering business thinking.', 17.75, 28, 'Business Insider Press', 2, 9, 'https://images.unsplash.com/photo-1508385082359-f38ae991e8f2', 2),
(27, 'Zero to Success', 'Stories of top business leaders and how they built empires from scratch.', 21.49, 20, 'Entrepreneur Books', 2, 9, 'https://images.unsplash.com/photo-1523287562758-66c7fc58967a', 2),
(28, 'The Wonders of Science', 'An engaging introduction to scientific discoveries that changed the world.', 16.99, 40, 'National Science Press', 2, 10, 'https://images.unsplash.com/photo-1581092334725-68f31738dcec', 2),
(29, 'Beyond the Atom', 'A deep dive into physics, chemistry, and the building blocks of matter.', 18.49, 26, 'MIT Press', 2, 10, 'https://images.unsplash.com/photo-1573497019575-626b611f31f6', 2),
(30, 'Exploring the Unknown', 'A fascinating guide through space, biology, and the mysteries of the universe.', 20.00, 18, 'Scientific Minds', 2, 10, 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e', 5),
(31, 'The Quantum Universe', 'An engaging introduction to quantum mechanics and the strange world of particles.', 19.99, 50, 'HarperScience', 3, 11, 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f', 5),
(32, 'Physics for Curious Minds', 'A simplified explanation of motion, energy, and the forces that govern our world.', 14.50, 35, 'NovaPress', 3, 11, 'https://images.unsplash.com/photo-1509021436665-8f07dbf5bf1d', 4),
(33, 'Life on Earth', 'A detailed look at living organisms and the systems that support life.', 22.99, 40, 'BioLearn Publications', 3, 12, 'https://images.unsplash.com/photo-1559757175-5700dde67544', 5),
(34, 'Human Body Explained', 'A visual guide to human anatomy, organs, and biological functions.', 17.80, 25, 'Insight Books', 3, 12, 'https://images.unsplash.com/photo-1559757175-2f0ebd097d3d', 4),
(35, 'Wonders of the Universe', 'A journey through stars, galaxies, and cosmic phenomena.', 25.00, 60, 'Cosmos House', 3, 13, 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3', 5),
(36, 'Beginner\'s Guide to Astronomy', 'A simple introduction to planets, stars, and space exploration.', 13.99, 30, 'StarView Publishers', 3, 13, 'https://images.unsplash.com/photo-1473929731524-15be24c8fdf4', 3),
(37, 'The Magic of Chemistry', 'An exploration of chemical reactions, compounds, and the science behind everyday materials.', 18.75, 45, 'ChemLab Press', 3, 14, 'https://images.unsplash.com/photo-1581091012184-5c72b47f9f13', 4),
(38, 'Chemistry Basics Simplified', 'A beginner-friendly overview of atoms, molecules, and scientific principles.', 11.99, 20, 'ElementBooks', 3, 14, 'https://images.unsplash.com/photo-1581091012184-5c72b47f9f13', 3),
(39, 'Science for Everyone', 'A general-interest science book written for people of all backgrounds.', 15.49, 55, 'Public Knowledge', 3, 15, 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f', 5),
(40, 'Amazing Facts of Science', 'A collection of fascinating scientific discoveries and concepts.', 12.90, 40, 'DiscoverMore', 3, 15, 'https://images.unsplash.com/photo-1509021436665-8f07dbf5bf1d', 4),
(41, 'Mastering Graphic Design', 'An in-depth guide to visual communication, composition, and professional design workflows.', 24.99, 40, 'Creative House', 5, 16, 'https://images.unsplash.com/photo-1498050108023-c5249f4df085', 5),
(42, 'Modern Graphic Techniques', 'A practical book on typography, layout, branding, and modern visual styles.', 18.50, 30, 'DesignLab Press', 5, 16, 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee', 4),
(43, 'UI/UX Design Essentials', 'A complete beginner guide to interface design, usability, wireframes, and user journeys.', 21.75, 50, 'UX Studio Publishers', 5, 17, 'https://images.unsplash.com/photo-1559028012-481c04fa702d', 5),
(44, 'Designing for Humans', 'A deep dive into user-centered design, accessibility, and intuitive product creation.', 19.99, 45, 'HumanFactor Press', 5, 17, 'https://images.unsplash.com/photo-1559028012-dae2a0e5e2fe', 4),
(45, 'The Complete Web Design Handbook', 'A modern overview of layouts, responsive design, UI patterns, CSS frameworks, and design systems.', 23.99, 60, 'WebWorks Media', 5, 18, 'https://images.unsplash.com/photo-1498050108023-c5249f4df085', 5),
(46, 'Web Design for Beginners', 'Simple explanations of HTML structure, color usage, typography, and layout planning.', 16.99, 28, 'NextGen Books', 5, 18, 'https://images.unsplash.com/photo-1518779578993-ec3579fee39f', 3),
(47, 'The Art of Logo Creation', 'A guide to designing professional logos that reflect identity, balance, and brand personality.', 20.00, 35, 'BrandCraft Press', 5, 19, 'https://images.unsplash.com/photo-1581276879432-15a7041f3c5e', 5),
(48, 'Logo Design Simplified', 'A beginner-friendly approach to logos, grids, shapes, and timeless branding principles.', 14.80, 22, 'Iconic Media', 5, 19, 'https://images.unsplash.com/photo-1581276879432-15a7041f3c5e', 4),
(49, 'Color Theory for Designers', 'A practical guide to color harmony, palettes, contrasts, and emotional color psychology.', 18.25, 40, 'Spectrum House', 5, 20, 'https://images.unsplash.com/photo-1501594907352-04cda38ebc29', 5),
(50, 'Understanding Color in Design', 'A deep exploration into hues, shades, tones, gradients, and visual balance.', 17.99, 33, 'Palette Press', 5, 20, 'https://images.unsplash.com/photo-1501594907352-04cda38ebc29', 4),
(51, 'Learn Python the Easy Way', 'A beginner-friendly guide to Python programming, covering functions, loops, and real-world projects.', 22.99, 50, 'TechPress', 4, NULL, 'https://images.unsplash.com/photo-1581091012184-5c72b47f9f13', 5),
(52, 'Mastering JavaScript', 'An advanced book on JavaScript concepts including closures, async programming, and modern ES standards.', 27.50, 40, 'CodeMasters', 4, NULL, 'https://images.unsplash.com/photo-1518779578993-ec3579fee39f', 4),
(53, 'Full Stack Development with Node.js', 'A practical guide to backend development using Node.js, Express, MongoDB, and REST APIs.', 30.00, 35, 'WebCraft Publishing', 4, NULL, 'https://images.unsplash.com/photo-1517433456452-f9633a875f6f', 5),
(54, 'C++ Programming for Beginners', 'An easy-to-understand introduction to C++, covering OOP, pointers, memory, and problem solving.', 18.75, 45, 'ProTech Books', 4, NULL, 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935', 4),
(55, 'The Complete Java Handbook', 'Everything you need to know about Java programming, from basic syntax to advanced enterprise concepts.', 28.90, 60, 'CodeLine Publications', 4, NULL, 'https://images.unsplash.com/photo-1519389950473-47ba0277781c', 5),
(56, 'Web Development with HTML & CSS', 'A beginner-friendly guide to creating modern responsive websites using HTML5 and CSS3.', 15.99, 70, 'FrontEnd Press', 4, NULL, 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6', 4),
(57, 'Introduction to Data Structures', 'A complete explanation of arrays, stacks, linked lists, graphs, and algorithms with examples.', 20.50, 30, 'AlgoTech Media', 4, NULL, 'https://images.unsplash.com/photo-1555949963-aa79dcee981c', 5),
(58, 'React.js in Action', 'A practical guide to building modern web applications using React hooks, components, and state management.', 26.49, 32, 'JSWorld Publishers', 4, NULL, 'https://images.unsplash.com/photo-1555617117-08fda9fb8c43', 4);

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `added_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `quantity`, `added_on`) VALUES
(4, 1, 1, '2025-11-25 09:42:13');

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` int(11) NOT NULL,
  `cart_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Fiction', 'Books that contain imaginative storytelling'),
(2, 'Non-Fiction', 'Books based on real facts and information'),
(3, 'Science', 'Books related to scientific concepts and discoveries'),
(4, 'Programming', 'Technical books about coding and software development'),
(5, 'Design & Arts', 'Books about creativity, design, and visual arts');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` int(99) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_key` varchar(100) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `shipping_address` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(50) DEFAULT 'processing'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_key`, `order_date`, `payment_type`, `total_amount`, `shipping_address`, `user_id`, `created_at`, `updated_at`, `status`) VALUES
(3, 'ORD_6924acf716a2a', '2025-11-24 20:07:35', 'COD', 29.98, 'pk', 1, '2025-11-25 00:07:35', '2025-11-25 00:07:35', 'processing'),
(4, 'ORD_6924ad39b2689', '2025-11-24 20:08:41', 'COD', 29.98, 'pk', 1, '2025-11-25 00:08:41', '2025-11-25 00:08:41', 'processing'),
(5, 'ORD_6924ad66e20e3', '2025-11-24 20:09:26', 'COD', 14.99, 'weweweewew', 1, '2025-11-25 00:09:26', '2025-11-25 00:09:26', 'processing'),
(10, 'ORD_69272c729eba9', '2025-11-26 17:36:02', 'COD', 109.49, 'asdflkv', 1, '2025-11-26 08:36:02', '2025-11-26 08:36:02', 'processing'),
(11, 'ORD_69272ccd2fe6d', '2025-11-26 17:37:33', 'COD', 51.99, 'afghugkgkj', 1, '2025-11-26 08:37:33', '2025-11-26 08:37:33', 'processing'),
(12, 'ORD_69272fa7f1f97', '2025-11-26 17:49:43', 'COD', 67.48, 'asertyuijh', 1, '2025-11-26 08:49:43', '2025-11-26 08:49:43', 'processing'),
(13, 'ORD_69272feb0ffc6', '2025-11-26 17:50:51', 'COD', 88.48, 'sdfhhjhhgf', 1, '2025-11-26 08:50:51', '2025-11-26 08:50:51', 'processing'),
(14, 'ORD_6927302cf054e', '2025-11-26 17:51:56', 'COD', 42.97, 'qwertyuhbn', 1, '2025-11-26 08:51:56', '2025-11-26 08:51:56', 'processing'),
(15, 'ORD_69273bba5fcc6', '2025-11-26 18:41:14', 'COD', 42.48, 'qwsdfghyuiouytfds', 1, '2025-11-26 09:41:14', '2025-11-26 09:41:14', 'processing'),
(16, 'ORD_6928182890c58', '2025-11-27 10:21:44', 'COD', 12.50, 'swedtgyujikopijhbfgcxdser5t678u9io', 1, '2025-11-27 01:21:44', '2025-11-27 01:21:44', 'processing'),
(17, 'ORD_692c36e0d6ab8', '2025-11-30 13:21:52', 'COD', 29.98, 'farah khan', 1, '2025-11-30 04:21:52', '2025-11-30 04:21:52', 'processing');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `book_id`, `quantity`, `created_at`, `updated_at`) VALUES
(3, 3, 1, 2, '2025-11-25 00:07:35', '2025-11-25 00:07:35'),
(4, 4, 1, 2, '2025-11-25 00:08:41', '2025-11-25 00:08:41'),
(5, 5, 1, 1, '2025-11-25 00:09:26', '2025-11-25 00:09:26'),
(20, 10, 5, 1, '2025-11-26 08:36:02', '2025-11-26 08:36:02'),
(21, 10, 8, 5, '2025-11-26 08:36:02', '2025-11-26 08:36:02'),
(22, 10, 5, 1, '2025-11-26 08:36:02', '2025-11-26 08:36:02'),
(23, 10, 8, 5, '2025-11-26 08:36:02', '2025-11-26 08:36:02'),
(24, 11, 16, 1, '2025-11-26 08:37:33', '2025-11-26 08:37:33'),
(25, 11, 17, 2, '2025-11-26 08:37:33', '2025-11-26 08:37:33'),
(26, 11, 16, 1, '2025-11-26 08:37:33', '2025-11-26 08:37:33'),
(27, 11, 17, 2, '2025-11-26 08:37:33', '2025-11-26 08:37:33'),
(28, 12, 2, 3, '2025-11-26 08:49:44', '2025-11-26 08:49:44'),
(29, 13, 8, 3, '2025-11-26 08:50:51', '2025-11-26 08:50:51'),
(30, 14, 19, 1, '2025-11-26 08:51:56', '2025-11-26 08:51:56'),
(31, 15, 1, 2, '2025-11-26 09:41:14', '2025-11-26 09:41:14'),
(32, 15, 2, 1, '2025-11-26 09:41:14', '2025-11-26 09:41:14'),
(33, 16, 2, 1, '2025-11-27 01:21:44', '2025-11-27 01:21:44'),
(34, 17, 1, 2, '2025-11-30 04:21:52', '2025-11-30 04:21:52');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_id` int(99) NOT NULL,
  `Order_id` int(99) NOT NULL,
  `Amount` varchar(255) NOT NULL,
  `Payment method` varchar(255) NOT NULL,
  `Payment_date` date NOT NULL,
  `Payment_status` varchar(255) NOT NULL,
  `Payment_reference` varchar(255) NOT NULL,
  `Transaction_id` int(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `Sale_id` int(99) NOT NULL,
  `Order_id` int(99) NOT NULL,
  `Customer_id` int(99) NOT NULL,
  `Payment_id` int(99) NOT NULL,
  `Sale_date` date NOT NULL,
  `Total_amount` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `name`, `description`, `category_id`) VALUES
(1, 'Mystery & Thriller', 'Stories filled with suspense, crime, investigations, and thrilling twists.', 1),
(2, 'Romance', 'Stories focused on love, relationships, and emotional connections.', 1),
(3, 'Fantasy', 'Fiction with magical worlds, mythical creatures, and imaginative adventures.', 1),
(4, 'Science Fiction', 'Futuristic stories based on science, technology, and space exploration.', 1),
(5, 'Classic Literature', 'Timeless works of literature known for their cultural and artistic value.', 1),
(6, 'Biography', 'Books that detail the life stories of real people.', 2),
(7, 'History', 'Books that explore past events and civilizations.', 2),
(8, 'Self-Help', 'Books focused on personal development and growth.', 2),
(9, 'Business', 'Books on business, management, and entrepreneurship.', 2),
(10, 'Science', 'Books that explain scientific concepts and discoveries.', 2),
(11, 'Physics', 'Books covering the study of matter, motion, energy, and forces.', 3),
(12, 'Biology', 'Books focused on living organisms and life sciences.', 3),
(13, 'Astronomy', 'Books about space, planets, stars, and the universe.', 3),
(14, 'Chemistry', 'Books related to chemicals, compounds, and scientific reactions.', 3),
(15, 'Popular Science', 'Easily understandable science books for the general public.', 3),
(16, 'Graphic Design', 'Books covering visual communication and graphic creation.', 5),
(17, 'UI/UX Design', 'Books focused on user interface and user experience design principles.', 5),
(18, 'Web Design', 'Books about designing websites, layouts, and digital visuals.', 5),
(19, 'Logo Design', 'Books related to creating and designing brand logos.', 5),
(20, 'Color Theory', 'Books explaining color harmony, palettes, and visual aesthetics.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'Visiting User', 'demomail@gmail.com', '$2y$10$GxE0zEWLhh51Fu.mbYOXiOUATaoTZah6nwhjG3oOzj5kUvo4Iioue', '2025-11-21 17:43:17'),
(6, 'Farah khan', 'fk5816029@gmail.com', '$2y$10$8fJ1dZY4HA9XGqu35uZg2O682XlPCSUNtaOyUOS0iPIt5i9E0feOG', '2025-11-30 12:31:46'),
(7, 'farahkhan', 'kk1033679@gmail.com', '$2y$10$VlwT/tEEL65vNI8zraZ8h.Sw/xLs5ImNbWUc.aFdertfacnPzOHtq', '2025-11-30 12:32:12'),
(8, 'Aqsa khan', 'aqsa@1234', '$2y$10$NMY6SA5.O/H6e4Seqr3i6e64TU2LZ.dU/BWCaizrzrOD1qaw.XV4i', '2025-11-30 12:46:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_books_categories` (`category_id`),
  ADD KEY `fk_books_subcategory` (`subcategory_id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_carts_user` (`user_id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cartitems_book` (`book_id`),
  ADD KEY `fk_cartitems_cart` (`cart_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orders_user` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_orderitem_book` (`book_id`),
  ADD KEY `fk_orderitem_order` (`order_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_id`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`Sale_id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_id` int(99) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_id` int(99) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Payment_id` int(99) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `Sale_id` int(99) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `fk_books_categories` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `fk_books_subcategory` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `fk_carts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `fk_cartitems_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cartitems_cart` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_orderitem_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_orderitem_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
